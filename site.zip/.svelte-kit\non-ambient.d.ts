
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	export interface AppTypes {
		RouteId(): "/" | "/api" | "/docs" | "/docs/[slug]" | "/download" | "/home" | "/home/carrosel" | "/home/grid" | "/home/intro" | "/home/passoApasso" | "/layoutComponents" | "/layoutComponents/Headers" | "/play" | "/sobre";
		RouteParams(): {
			"/docs/[slug]": { slug: string }
		};
		LayoutParams(): {
			"/": { slug?: string };
			"/api": Record<string, never>;
			"/docs": { slug?: string };
			"/docs/[slug]": { slug: string };
			"/download": Record<string, never>;
			"/home": Record<string, never>;
			"/home/carrosel": Record<string, never>;
			"/home/grid": Record<string, never>;
			"/home/intro": Record<string, never>;
			"/home/passoApasso": Record<string, never>;
			"/layoutComponents": Record<string, never>;
			"/layoutComponents/Headers": Record<string, never>;
			"/play": Record<string, never>;
			"/sobre": Record<string, never>
		};
		Pathname(): "/" | "/api" | "/api/" | "/docs" | "/docs/" | `/docs/${string}` & {} | `/docs/${string}/` & {} | "/download" | "/download/" | "/home" | "/home/" | "/home/carrosel" | "/home/carrosel/" | "/home/grid" | "/home/grid/" | "/home/intro" | "/home/intro/" | "/home/passoApasso" | "/home/passoApasso/" | "/layoutComponents" | "/layoutComponents/" | "/layoutComponents/Headers" | "/layoutComponents/Headers/" | "/play" | "/play/" | "/sobre" | "/sobre/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/robots.txt" | string & {};
	}
}