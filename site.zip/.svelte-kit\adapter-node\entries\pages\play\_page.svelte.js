import { O as attr_class, P as clsx, M as store_get, N as escape_html, Q as unsubscribe_stores, z as pop, x as push } from "../../../chunks/index2.js";
import { r as razao } from "../../../chunks/tela.js";
function _page($$payload, $$props) {
  push();
  var $$store_subs;
  let codigo = "";
  let resultado = { logs: [] };
  $$payload.out.push(`<section id="PlaygroundSection"${attr_class(
    clsx(store_get($$store_subs ??= {}, "$razao", razao) > 1 ? "note" : store_get($$store_subs ??= {}, "$razao", razao) > 0.63 ? "tablet" : "cell"),
    "svelte-1aa8qgj"
  )}><h2 class="svelte-1aa8qgj">atenção, essa aba está em construção, e teste, nada está na versão final</h2> <h1 class="svelte-1aa8qgj"><span class="svelte-1aa8qgj">P</span> <span class="svelte-1aa8qgj">L</span> <span class="svelte-1aa8qgj">A</span> <span class="svelte-1aa8qgj">Y</span> <span class="svelte-1aa8qgj">G</span> <span class="svelte-1aa8qgj">R</span> <span class="svelte-1aa8qgj">O</span> <span class="svelte-1aa8qgj">U</span> <span class="svelte-1aa8qgj">N</span> <span class="svelte-1aa8qgj">D</span></h1> <div id="code" class="svelte-1aa8qgj"><div id="txt" class="svelte-1aa8qgj"><textarea rows="10" cols="50" placeholder="Digite seu código aqui..." class="svelte-1aa8qgj">`);
  const $$body = escape_html(codigo);
  if ($$body) {
    $$payload.out.push(`${$$body}`);
  }
  $$payload.out.push(`</textarea></div> <div id="result" class="svelte-1aa8qgj">`);
  {
    $$payload.out.push("<!--[!-->");
    if (resultado.logs.length) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<div id="resultadofinal" class="svelte-1aa8qgj">`);
      if (resultado.logs.length) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<pre class="logs svelte-1aa8qgj">${escape_html(resultado.logs.join("\n"))}</pre>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--> `);
      {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]--></div>`);
    } else {
      $$payload.out.push("<!--[!-->");
      $$payload.out.push(`<p class="svelte-1aa8qgj">o resultado aqui...</p>`);
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div></div> <button class="svelte-1aa8qgj">Executar</button></section>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
export {
  _page as default
};
