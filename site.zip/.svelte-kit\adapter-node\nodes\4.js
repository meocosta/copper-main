import * as universal from '../entries/pages/docs/_page.ts.js';

export const index = 4;
export { universal };
export const universal_id = "src/routes/docs/+page.ts";
export const imports = ["_app/immutable/nodes/4.DHL0iju_.js","_app/immutable/chunks/D0iwhpLH.js"];
export const stylesheets = [];
export const fonts = [];
