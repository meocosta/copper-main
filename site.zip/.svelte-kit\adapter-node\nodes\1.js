

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CBQiwfm2.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/Ce9jhLaN.js"];
export const stylesheets = ["_app/immutable/assets/1.DtOa4MbY.css"];
export const fonts = [];
