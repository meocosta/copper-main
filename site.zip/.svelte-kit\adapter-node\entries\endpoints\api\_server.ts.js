import { json } from "@sveltejs/kit";
import fs from "fs";
import path from "path";
function getFilePath(lang) {
  return path.resolve(`src/lib/translations/${lang}.json`);
}
function loadTranslations(lang) {
  const filePath = getFilePath(lang);
  const data = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(data);
}
function saveTranslations(lang, data) {
  const filePath = getFilePath(lang);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}
async function GET({ url }) {
  const lang = url.searchParams.get("lang") || "en-us";
  const translations = loadTranslations(lang);
  return json(translations);
}
async function POST({ request }) {
  const { lang = "en-us", path: jsonPath, value } = await request.json();
  const translations = loadTranslations(lang);
  const keys = jsonPath.split(".");
  let obj = translations;
  for (let i = 0; i < keys.length - 1; i++) {
    if (!obj[keys[i]]) obj[keys[i]] = {};
    obj = obj[keys[i]];
  }
  obj[keys[keys.length - 1]] = value;
  saveTranslations(lang, translations);
  return json({ success: true, lang, updated: { [jsonPath]: value } });
}
export {
  GET,
  POST
};
