import { C as Conteudo } from "../../../../chunks/Conteudo.js";
const slugify = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const load = ({ params }) => {
  const { slug } = params;
  const map = Conteudo("docs").map((item) => ({
    ...item,
    slug: slugify(item.title)
  }));
  const page = map.find((item) => item.slug === slug) ?? {
    id: 404
  };
  return { slug: params.slug, id: page.id };
};
export {
  load
};
