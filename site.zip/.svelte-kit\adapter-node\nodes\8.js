

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/sobre/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/8.BgMS0s4w.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/BBCc6uHp.js","_app/immutable/chunks/Ce9jhLaN.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/RTMQBieC.js","_app/immutable/chunks/Ca2N0swm.js","_app/immutable/chunks/BfGV9M9Z.js","_app/immutable/chunks/BSH_7Kz2.js"];
export const stylesheets = ["_app/immutable/assets/8.7h1YfSJa.css"];
export const fonts = [];
