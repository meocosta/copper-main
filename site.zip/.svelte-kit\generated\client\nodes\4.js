import * as universal from "../../../../src/routes/docs/+page.ts";
export { universal };