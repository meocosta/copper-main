import { redirect } from "@sveltejs/kit";
const load = () => {
  throw redirect(302, "/docs/introducao");
};
export {
  load
};
