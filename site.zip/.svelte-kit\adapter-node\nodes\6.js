

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/download/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.tthv0r1v.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/BfGV9M9Z.js","_app/immutable/chunks/BBCc6uHp.js","_app/immutable/chunks/Ce9jhLaN.js"];
export const stylesheets = ["_app/immutable/assets/6.DCpOD0rT.css"];
export const fonts = [];
