import"./DeSNcceG.js";import"./CqaOjL9a.js";import{h as i,a as N,f as b,aC as G,b as I,E as P,d as R,aD as B,R as D,J as M,c as O,l as x,k as C,G as H,p as J,w as L,z as V,af as q,aE as K,ab as S,aj as Q,a2 as W,aF as c,ac as U,ak as X,ae as Y,aG as Z,ai as $,g as w,aH as ee,aI as te}from"./D2NI_LFk.js";import{e as ae,i as se}from"./RTMQBieC.js";import{s as re}from"./D-rmIOUD.js";import{i as oe}from"./DGgH5txR.js";import{a as z}from"./BfGV9M9Z.js";import{i as ie}from"./BBCc6uHp.js";import{l as A,p as f}from"./BSH_7Kz2.js";function ne(v,t,u,m,_,y){let l=i;i&&N();var o,n,e=null;i&&b.nodeType===G&&(e=b,N());var h=i?b:v,a;I(()=>{const s=t()||null;var p=B;s!==o&&(a&&(s===null?J(a,()=>{a=null,n=null}):s===n?L(a):V(a)),s&&s!==n&&(a=R(()=>{if(e=i?e:document.createElementNS(p,s),D(e,e),m){i&&oe(s)&&e.append(document.createComment(""));var r=i?M(e):e.appendChild(O());i&&(r===null?x(!1):C(r)),m(e,r)}H.nodes_end=e,h.before(e)})),o=s,o&&(n=o))},P),l&&(x(!0),C(h))}/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const le={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var de=K("<svg><!><!></svg>");function be(v,t){const u=A(t,["children","$$slots","$$events","$$legacy"]),m=A(u,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);q(t,!1);let _=f(t,"name",8,void 0),y=f(t,"color",8,"currentColor"),l=f(t,"size",8,24),o=f(t,"strokeWidth",8,2),n=f(t,"absoluteStrokeWidth",8,!1),e=f(t,"iconNode",24,()=>[]);const h=(...r)=>r.filter((d,g,k)=>!!d&&k.indexOf(d)===g).join(" ");ie();var a=de();z(a,(r,d)=>({...le,...m,width:l(),height:l(),stroke:y(),"stroke-width":r,class:d}),[()=>(c(n()),c(o()),c(l()),W(()=>n()?Number(o())*24/Number(l()):o())),()=>(c(_()),c(u),W(()=>h("lucide-icon","lucide",_()?`lucide-${_()}`:"",u.class)))]);var s=U(a);ae(s,1,e,se,(r,d)=>{var g=ee(()=>te(w(d),2));let k=()=>w(g)[0],T=()=>w(g)[1];var E=Z(),j=$(E);ne(j,k,!0,(F,fe)=>{z(F,()=>({...T()}))}),S(r,E)});var p=X(s);re(p,t,"default",{}),Y(a),S(v,a),Q()}export{be as I};
