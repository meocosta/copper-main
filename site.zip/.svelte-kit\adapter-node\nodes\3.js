

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.9REiDN9E.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/BBCc6uHp.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/Ca2N0swm.js","_app/immutable/chunks/BSH_7Kz2.js","_app/immutable/chunks/D-rmIOUD.js","_app/immutable/chunks/C6-8pd6h.js","_app/immutable/chunks/RTMQBieC.js","_app/immutable/chunks/BfGV9M9Z.js","_app/immutable/chunks/Ce9jhLaN.js","_app/immutable/chunks/CAJekPQE.js","_app/immutable/chunks/Dqu3nJAb.js"];
export const stylesheets = ["_app/immutable/assets/3.CSvdLS4M.css"];
export const fonts = [];
