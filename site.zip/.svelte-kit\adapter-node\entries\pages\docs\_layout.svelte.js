import { M as store_get, R as ensure_array_like, A as attr, O as attr_class, N as escape_html, F as slot, Q as unsubscribe_stores, J as bind_props, z as pop, x as push } from "../../../chunks/index2.js";
import "../../../chunks/language.js";
import { r as razao } from "../../../chunks/tela.js";
import { C as Conteudo } from "../../../chunks/Conteudo.js";
import { p as page } from "../../../chunks/stores.js";
import { f as fallback } from "../../../chunks/equality.js";
function _layout($$payload, $$props) {
  push();
  var $$store_subs;
  const slugify = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  let map = fallback($$props["map"], () => Conteudo("docs").map((s) => ({ ...s, slug: slugify(s.title) })), true);
  let abaAtual;
  abaAtual = store_get($$store_subs ??= {}, "$page", page).url.pathname.split("/docs/").pop() ?? "";
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    const each_array = ensure_array_like(map);
    $$payload.out.push(`<section id="DocsNavegation" class="cell svelte-1ehxbu0"><nav class="svelte-1ehxbu0"><!--[-->`);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let m = each_array[$$index];
      $$payload.out.push(`<a${attr("href", `/docs/${m.slug}`)}${attr_class("svelte-1ehxbu0", void 0, { "ativo": abaAtual == m.slug })}>${escape_html(m.title)}</a>`);
    }
    $$payload.out.push(`<!--]--></nav> <section class="svelte-1ehxbu0"><!---->`);
    slot($$payload, $$props, "default", {});
    $$payload.out.push(`<!----></section></section>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    const each_array_1 = ensure_array_like(map);
    $$payload.out.push(`<section id="DocsNavegation" class="tablet svelte-1ehxbu0"><nav class="svelte-1ehxbu0"><!--[-->`);
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let m = each_array_1[$$index_1];
      $$payload.out.push(`<a${attr("href", `/docs/${m.slug}`)}${attr_class("svelte-1ehxbu0", void 0, { "ativo": abaAtual == m.slug })}>${escape_html(m.title)}</a>`);
    }
    $$payload.out.push(`<!--]--></nav> <section class="svelte-1ehxbu0"><!---->`);
    slot($$payload, $$props, "default", {});
    $$payload.out.push(`<!----></section></section>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    const each_array_2 = ensure_array_like(map);
    $$payload.out.push(`<section id="DocsNavegation" class="computador svelte-1ehxbu0"><nav class="svelte-1ehxbu0"><!--[-->`);
    for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
      let m = each_array_2[$$index_2];
      $$payload.out.push(`<a${attr("href", `/docs/${m.slug}`)}${attr_class("svelte-1ehxbu0", void 0, { "ativo": abaAtual == m.slug })}>${escape_html(m.title)}</a>`);
    }
    $$payload.out.push(`<!--]--></nav> <section class="svelte-1ehxbu0"><!---->`);
    slot($$payload, $$props, "default", {});
    $$payload.out.push(`<!----></section></section>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { map });
  pop();
}
export {
  _layout as default
};
