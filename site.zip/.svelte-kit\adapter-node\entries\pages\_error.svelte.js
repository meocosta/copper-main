import { M as store_get, Q as unsubscribe_stores } from "../../chunks/index2.js";
import { r as razao } from "../../chunks/tela.js";
import "../../chunks/language.js";
function _error($$payload) {
  var $$store_subs;
  $$payload.out.push(`<section class="erro svelte-11wwo2y">`);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div id="carinha" class="svelte-11wwo2y"><p class="svelte-11wwo2y">:(</p></div>`);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <div id="mensagem" class="svelte-11wwo2y"><h1 class="svelte-11wwo2y">página indisponível</h1> <p class="svelte-11wwo2y">A Copper Foundation sente muito pelo inconveniente! Nos mande um feedback sobre o erro (como ocorreu, qual o retorno em seu console...). Estamos trabalhando para te oferecer a melhor experiência!</p> <a href="mailto:saccopper@gmail.com" class="svelte-11wwo2y"><button class="svelte-11wwo2y">dar feedback</button></a></div></section>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
}
export {
  _error as default
};
