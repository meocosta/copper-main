import "clsx";
import { D as sanitize_props, E as spread_props, F as slot, N as escape_html, J as bind_props, z as pop, x as push, M as store_get, Q as unsubscribe_stores, R as ensure_array_like, O as attr_class, K as stringify } from "../../chunks/index2.js";
import { I as Icon } from "../../chunks/Icon.js";
import { f as fallback } from "../../chunks/equality.js";
import { h as html } from "../../chunks/html.js";
import { r as razao } from "../../chunks/tela.js";
import { t, l as lang } from "../../chunks/language.js";
function Bolt($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.542.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"
      }
    ],
    ["circle", { "cx": "12", "cy": "12", "r": "4" }]
  ];
  Icon($$payload, spread_props([
    { name: "bolt" },
    $$sanitized_props,
    {
      /**
       * @component @name Bolt
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEgMTZWOGEyIDIgMCAwIDAtMS0xLjczbC03LTRhMiAyIDAgMCAwLTIgMGwtNyA0QTIgMiAwIDAgMCAzIDh2OGEyIDIgMCAwIDAgMSAxLjczbDcgNGEyIDIgMCAwIDAgMiAwbDctNEEyIDIgMCAwIDAgMjEgMTZ6IiAvPgogIDxjaXJjbGUgY3g9IjEyIiBjeT0iMTIiIHI9IjQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bolt
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Bot($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.542.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 8V4H8" }],
    [
      "rect",
      { "width": "16", "height": "12", "x": "4", "y": "8", "rx": "2" }
    ],
    ["path", { "d": "M2 14h2" }],
    ["path", { "d": "M20 14h2" }],
    ["path", { "d": "M15 13v2" }],
    ["path", { "d": "M9 13v2" }]
  ];
  Icon($$payload, spread_props([
    { name: "bot" },
    $$sanitized_props,
    {
      /**
       * @component @name Bot
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgOFY0SDgiIC8+CiAgPHJlY3Qgd2lkdGg9IjE2IiBoZWlnaHQ9IjEyIiB4PSI0IiB5PSI4IiByeD0iMiIgLz4KICA8cGF0aCBkPSJNMiAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0yMCAxNGgyIiAvPgogIDxwYXRoIGQ9Ik0xNSAxM3YyIiAvPgogIDxwYXRoIGQ9Ik05IDEzdjIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/bot
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Code_xml($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.542.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "m18 16 4-4-4-4" }],
    ["path", { "d": "m6 8-4 4 4 4" }],
    ["path", { "d": "m14.5 4-5 16" }]
  ];
  Icon($$payload, spread_props([
    { name: "code-xml" },
    $$sanitized_props,
    {
      /**
       * @component @name CodeXml
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTggMTYgNC00LTQtNCIgLz4KICA8cGF0aCBkPSJtNiA4LTQgNCA0IDQiIC8+CiAgPHBhdGggZD0ibTE0LjUgNC01IDE2IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/code-xml
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Play($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.542.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "play" },
    $$sanitized_props,
    {
      /**
       * @component @name Play
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNSA1YTIgMiAwIDAgMSAzLjAwOC0xLjcyOGwxMS45OTcgNi45OThhMiAyIDAgMCAxIC4wMDMgMy40NThsLTEyIDdBMiAyIDAgMCAxIDUgMTl6IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/play
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Test_tube_diagonal($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  /**
   * @license lucide-svelte v0.542.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   * ---
   *
   * The MIT License (MIT) (for portions derived from Feather)
   *
   * Copyright (c) 2013-2023 Cole Bemis
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all
   * copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M21 7 6.82 21.18a2.83 2.83 0 0 1-3.99-.01a2.83 2.83 0 0 1 0-4L17 3"
      }
    ],
    ["path", { "d": "m16 2 6 6" }],
    ["path", { "d": "M12 16H4" }]
  ];
  Icon($$payload, spread_props([
    { name: "test-tube-diagonal" },
    $$sanitized_props,
    {
      /**
       * @component @name TestTubeDiagonal
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMjEgNyA2LjgyIDIxLjE4YTIuODMgMi44MyAwIDAgMS0zLjk5LS4wMWEyLjgzIDIuODMgMCAwIDEgMC00TDE3IDMiIC8+CiAgPHBhdGggZD0ibTE2IDIgNiA2IiAvPgogIDxwYXRoIGQ9Ik0xMiAxNkg0IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/test-tube-diagonal
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: ($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {});
        $$payload2.out.push(`<!---->`);
      },
      $$slots: { default: true }
    }
  ]));
}
function Tablet$2($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let botoes = fallback($$props["botoes"], () => [], true);
  $$payload.out.push(`<section id="IntroHome" class="svelte-v6vjp4"><h2 class="svelte-v6vjp4">${html(conteudo[0])}</h2> <h3 class="svelte-v6vjp4">${escape_html(conteudo[1])}</h3> <div id="botoes" class="svelte-v6vjp4"><button id="teste" class="svelte-v6vjp4"><a href="/play" class="svelte-v6vjp4">`);
  Test_tube_diagonal($$payload, {});
  $$payload.out.push(`<!----> ${escape_html(botoes[0])}</a></button> <button id="start" class="svelte-v6vjp4"><a href="/docs/introducao" class="svelte-v6vjp4">`);
  Play($$payload, {});
  $$payload.out.push(`<!----> ${escape_html(botoes[1])}</a></button></div></section>`);
  bind_props($$props, { conteudo, botoes });
  pop();
}
function Note$3($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let botoes = fallback($$props["botoes"], () => [], true);
  $$payload.out.push(`<section id="IntroHome" class="svelte-1jn52vb"><h2 class="svelte-1jn52vb">${html(conteudo[0])}</h2> <h3 class="svelte-1jn52vb">${escape_html(conteudo[1])}</h3> <div id="botoes" class="svelte-1jn52vb"><button id="teste" class="svelte-1jn52vb"><a href="/play" class="svelte-1jn52vb">`);
  Test_tube_diagonal($$payload, {});
  $$payload.out.push(`<!----> ${escape_html(botoes[0])}</a></button> <button id="start" class="svelte-1jn52vb"><a href="/docs/introducao" class="svelte-1jn52vb">`);
  Play($$payload, {});
  $$payload.out.push(`<!----> ${escape_html(botoes[1])}</a></button></div></section>`);
  bind_props($$props, { conteudo, botoes });
  pop();
}
function Cellphone$2($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let botoes = fallback($$props["botoes"], () => [], true);
  $$payload.out.push(`<section id="IntroHome" class="svelte-sg00a3"><h2 class="svelte-sg00a3">${html(conteudo[0])}</h2> <h3 class="svelte-sg00a3">${escape_html(conteudo[1])}</h3> <div id="botoes" class="svelte-sg00a3"><button id="teste" class="svelte-sg00a3"><a href="/play" class="svelte-sg00a3">`);
  Test_tube_diagonal($$payload, {});
  $$payload.out.push(`<!----> <p>${escape_html(botoes[0])}</p></a></button> <button id="start" class="svelte-sg00a3"><a href="/docs/introducao" class="svelte-sg00a3">`);
  Play($$payload, {});
  $$payload.out.push(`<!----> <p>${escape_html(botoes[1])}</p></a></button></div></section>`);
  bind_props($$props, { conteudo, botoes });
  pop();
}
function Intro($$payload, $$props) {
  push();
  var $$store_subs;
  let path = "home.intro";
  let conteudo = [t(path + ".titulo"), t(path + ".subtitulo")];
  let botoes = [t(path + ".botoes.teste"), t(path + ".botoes.start")];
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    conteudo = [t(path + ".titulo"), t(path + ".subtitulo")];
    botoes = [t(path + ".botoes.teste"), t(path + ".botoes.start")];
  }
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    Cellphone$2($$payload, { conteudo, botoes });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Tablet$2($$payload, { conteudo, botoes });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note$3($$payload, { conteudo, botoes });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Note$2($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let titulo = fallback($$props["titulo"], "");
  let subtitulo = fallback($$props["subtitulo"], "");
  let posicoes = ["d1", "a", "d2"];
  let indices = [];
  const each_array = ensure_array_like(conteudo);
  $$payload.out.push(`<section id="ferramentas" class="svelte-dln6mi"><div id="txt" class="svelte-dln6mi"><h2 class="svelte-dln6mi">${html(titulo)}</h2> <p class="svelte-dln6mi">${escape_html(subtitulo)}</p></div> <div id="carrosel" class="svelte-dln6mi"><!--[-->`);
  for (let key = 0, $$length = each_array.length; key < $$length; key++) {
    let c = each_array[key];
    $$payload.out.push(`<div${attr_class(`card ${stringify(posicoes[indices[key]])}`, "svelte-dln6mi")}><h3 class="svelte-dln6mi">${escape_html(c.nome)}</h3> <p class="svelte-dln6mi">${escape_html(c.txt)}</p></div>`);
  }
  $$payload.out.push(`<!--]--></div></section>`);
  bind_props($$props, { conteudo, titulo, subtitulo });
  pop();
}
function Tablet$1($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let titulo = fallback($$props["titulo"], "");
  let selecionado = conteudo[0];
  let count = 1;
  setInterval(
    () => {
      switch (count) {
        case 1:
          selecionado = conteudo[0];
          count++;
          break;
        case 2:
          selecionado = conteudo[1];
          count++;
          break;
        case 3:
          selecionado = conteudo[2];
          count = 1;
          break;
      }
    },
    7e3
  );
  {
    selecionado = conteudo[count - 1];
  }
  $$payload.out.push(`<section id="CarroselHome" class="svelte-1snzxln"><h2 class="svelte-1snzxln">${html(titulo)}</h2> <div id="card" class="svelte-1snzxln"><div class="svelte-1snzxln"><!---->`);
  selecionado.icon?.($$payload, { class: "icone" });
  $$payload.out.push(`<!----> <h3 class="svelte-1snzxln">${escape_html(selecionado.nome)}</h3></div> <p class="svelte-1snzxln">${escape_html(selecionado.txt)}</p></div> <div id="bals" class="svelte-1snzxln"><div${attr_class("ball svelte-1snzxln", void 0, { "ativo": count == 1 })}></div> <div${attr_class("ball svelte-1snzxln", void 0, { "ativo": count == 2 })}></div> <div${attr_class("ball svelte-1snzxln", void 0, { "ativo": count == 3 })}></div></div></section>`);
  bind_props($$props, { conteudo, titulo });
  pop();
}
function Cell($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let titulo = fallback($$props["titulo"], "");
  let selecionado = conteudo[0];
  let count = 1;
  setInterval(
    () => {
      switch (count) {
        case 1:
          selecionado = conteudo[0];
          count++;
          break;
        case 2:
          selecionado = conteudo[1];
          count++;
          break;
        case 3:
          selecionado = conteudo[2];
          count = 1;
          break;
      }
    },
    7e3
  );
  {
    selecionado = conteudo[count - 1];
  }
  $$payload.out.push(`<section id="CarroselHome" class="svelte-6wm8ts"><h2 class="svelte-6wm8ts">${html(titulo)}</h2> <div id="card" class="svelte-6wm8ts"><!---->`);
  selecionado.icon?.($$payload, { class: "icone" });
  $$payload.out.push(`<!----> <h3 class="svelte-6wm8ts">${escape_html(selecionado.nome)}</h3> <p class="svelte-6wm8ts">${escape_html(selecionado.txt)}</p></div> <div id="bals" class="svelte-6wm8ts"><div${attr_class("ball svelte-6wm8ts", void 0, { "ativo": count == 1 })}></div> <div${attr_class("ball svelte-6wm8ts", void 0, { "ativo": count == 2 })}></div> <div${attr_class("ball svelte-6wm8ts", void 0, { "ativo": count == 3 })}></div></div></section>`);
  bind_props($$props, { conteudo, titulo });
  pop();
}
function Carrosel($$payload, $$props) {
  push();
  var $$store_subs;
  let icons = [Bolt, Code_xml, Bot];
  let conteudo = achaConteudo("home.cards");
  let titulo = t("home.cards.titulo");
  let subtitulo = t("home.cards.subtitulo");
  function achaConteudo(path) {
    let returnContent = [];
    let qttd = Number(t(path + ".quantidade"));
    for (let i = 1; i <= qttd; i++) {
      returnContent.push({
        icon: icons[i - 1],
        nome: t(path + ".conteudo" + i + ".nome"),
        txt: t(path + ".conteudo" + i + ".txt")
      });
    }
    return returnContent;
  }
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    conteudo = achaConteudo("home.cards");
    titulo = t("home.cards.titulo");
    subtitulo = t("home.cards.subtitulo");
  }
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    Cell($$payload, { titulo, conteudo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Tablet$1($$payload, { titulo, conteudo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note$2($$payload, { titulo, conteudo, subtitulo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Note$1($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  $$payload.out.push(`<section id="grid" class="svelte-z9unzm"><div class="parent svelte-z9unzm"><div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm">${html(conteudo[0].txt)}</p></div> <div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm">${html(conteudo[1].nome)}</h3></div> <div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm">${html(conteudo[1].txt)}</p></div></div> <div class="parent2 svelte-z9unzm"><div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm">${html(conteudo[0].nome)}</h3></div> <div id="code" class="svelte-z9unzm"><pre class="svelte-z9unzm">
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm">${html(conteudo[2].txt)}</p></div> <div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm">${html(conteudo[2].nome)}</h3></div></div></section>`);
  bind_props($$props, { conteudo });
  pop();
}
function Tablet($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  $$payload.out.push(`<section id="grid" class="svelte-1yobebi"><div class="parent svelte-1yobebi"><div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi">${html(conteudo[0].txt)}</p></div> <div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi">${html(conteudo[1].nome)}</h3></div> <div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi">${html(conteudo[1].txt)}</p></div></div> <div class="parent2 svelte-1yobebi"><div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi">${html(conteudo[0].nome)}</h3></div> <div id="code" class="svelte-1yobebi"><pre class="svelte-1yobebi">
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi">${html(conteudo[2].txt)}</p></div> <div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi">${html(conteudo[2].nome)}</h3></div></div></section>`);
  bind_props($$props, { conteudo });
  pop();
}
function Cellphone$1($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  $$payload.out.push(`<section id="grid" class="svelte-1efg8av"><div class="parent svelte-1efg8av"><div id="div1" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av">${html(conteudo[0].txt)}</p></div> <div id="div2" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av">${html(conteudo[0].nome)}</h3></div> <div id="code" class="svelte-1efg8av"><pre>
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div id="div4" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av">${html(conteudo[2].nome)}</h3></div> <div id="div5" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av">${html(conteudo[2].txt)}</p></div> <div id="div6" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av">${html(conteudo[1].nome)}</h3></div> <div id="div7" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av">${html(conteudo[1].txt)}</p></div></div></section>`);
  bind_props($$props, { conteudo });
  pop();
}
function Grid($$payload, $$props) {
  push();
  var $$store_subs;
  let conteudo = achaConteudo("home.carrosel");
  function achaConteudo(path) {
    let returnContent = [];
    let qttd = Number(t(path + ".quantidade"));
    for (let i = 1; i <= qttd; i++) {
      returnContent.push({
        nome: t(path + ".conteudo" + i + ".nome"),
        txt: t(path + ".conteudo" + i + ".txt")
      });
    }
    return returnContent;
  }
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    conteudo = achaConteudo("home.carrosel");
  }
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    Cellphone$1($$payload, { conteudo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Tablet($$payload, { conteudo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note$1($$payload, { conteudo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Note($$payload, $$props) {
  push();
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let slogan = $$props["slogan"];
  let titulo = $$props["titulo"];
  const each_array = ensure_array_like(conteudo);
  $$payload.out.push(`<section class="passo svelte-1ubha5p"><div class="card-slogan svelte-1ubha5p"><h2 class="svelte-1ubha5p">${html(slogan)}</h2></div> <div class="passos svelte-1ubha5p"><h2 class="svelte-1ubha5p">${escape_html(titulo)}</h2> <div><!--[-->`);
  for (let i = 0, $$length = each_array.length; i < $$length; i++) {
    let item = each_array[i];
    $$payload.out.push(`<div class="conteudo svelte-1ubha5p"><div class="key svelte-1ubha5p"><p>${escape_html(i + 1)}</p></div> <div class="txt svelte-1ubha5p"><h3 class="svelte-1ubha5p">${escape_html(item.nome)}</h3> <p class="svelte-1ubha5p">${escape_html(item.txt)}</p></div></div> `);
    if (i + 1 != conteudo.length) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<p class="listra svelte-1ubha5p">|</p>`);
    } else {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div></div></section>`);
  bind_props($$props, { conteudo, slogan, titulo });
  pop();
}
function Cellphone($$payload, $$props) {
  let conteudo = fallback($$props["conteudo"], () => [], true);
  let slogan = $$props["slogan"];
  let titulo = $$props["titulo"];
  const each_array = ensure_array_like(conteudo);
  $$payload.out.push(`<section id="passo" class="svelte-oa6t8v"><div id="cardSlogan" class="svelte-oa6t8v"><h2 class="svelte-oa6t8v">${html(slogan)}</h2></div> <div id="passos" class="svelte-oa6t8v"><div id="divs" class="svelte-oa6t8v"><!--[-->`);
  for (let key = 0, $$length = each_array.length; key < $$length; key++) {
    let conteudo2 = each_array[key];
    $$payload.out.push(`<div class="conteudo svelte-oa6t8v"><div id="key" class="svelte-oa6t8v"><p class="svelte-oa6t8v">${escape_html(key + 1)}</p></div> <div id="txt" class="svelte-oa6t8v"><h3 class="svelte-oa6t8v">${escape_html(conteudo2.nome)}</h3> <p class="svelte-oa6t8v">${escape_html(conteudo2.txt)}</p></div></div> `);
    if (key + 1 != 3) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<hr class="svelte-oa6t8v"/>`);
    } else {
      $$payload.out.push("<!--[!-->");
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--></div></div></section>`);
  bind_props($$props, { conteudo, slogan, titulo });
}
function Passo($$payload, $$props) {
  push();
  var $$store_subs;
  let conteudo = achaConteudo("home.passo");
  let titulo = t("home.passo.titulo");
  let slogan = t("home.passo.slogan");
  function achaConteudo(path) {
    let returnContent = [];
    let qttd = Number(t(path + ".quantidade"));
    for (let i = 1; i <= qttd; i++) {
      returnContent.push({
        nome: t(path + ".passo" + i + ".nome"),
        txt: t(path + ".passo" + i + ".txt")
      });
    }
    return returnContent;
  }
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    conteudo = achaConteudo("home.passo");
    titulo = t("home.passo.titulo");
    slogan = t("home.passo.slogan");
  }
  if (store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Cellphone($$payload, { conteudo, slogan, titulo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note($$payload, { conteudo, slogan, titulo });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function _page($$payload) {
  Intro($$payload);
  $$payload.out.push(`<!----> `);
  Carrosel($$payload);
  $$payload.out.push(`<!----> `);
  Passo($$payload);
  $$payload.out.push(`<!----> `);
  Grid($$payload);
  $$payload.out.push(`<!---->`);
}
export {
  _page as default
};
