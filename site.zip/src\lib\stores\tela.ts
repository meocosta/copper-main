import { writable } from 'svelte/store';

export const viewheight = writable(0);
export const viewwidth = writable(0);
export const razao = writable(0);
export const height = writable(0);
export const categoria = writable(1)