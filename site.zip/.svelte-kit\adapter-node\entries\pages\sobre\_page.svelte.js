import { R as ensure_array_like, N as escape_html, A as attr, J as bind_props, z as pop, x as push, M as store_get, Q as unsubscribe_stores } from "../../../chunks/index2.js";
import { r as razao } from "../../../chunks/tela.js";
import { t, l as lang } from "../../../chunks/language.js";
import { h as html } from "../../../chunks/html.js";
function Cell($$payload, $$props) {
  push();
  let sobre = $$props["sobre"];
  const each_array = ensure_array_like(sobre.porque.porque.paragrafos);
  const each_array_1 = ensure_array_like(sobre.porque.questoes.conteudo);
  const each_array_2 = ensure_array_like(sobre.velocidade.paragrafos);
  const each_array_3 = ensure_array_like(sobre.motor.paragrafos);
  const each_array_4 = ensure_array_like(sobre.linguagens.lista);
  $$payload.out.push(`<section id="sobre" class="svelte-1bib3sa"><section id="sobreIntro" class="svelte-1bib3sa"><h1 class="svelte-1bib3sa">${html(sobre.intro.titulo)}</h1> <h2 class="svelte-1bib3sa">${html(sobre.intro.subtitulo)}</h2></section> <section id="sobrePorque" class="svelte-1bib3sa"><div id="porque" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${escape_html(sobre.porque.porque.titulo)}</h2> <!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let p = each_array[$$index];
    $$payload.out.push(`<p class="svelte-1bib3sa">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></div> <div id="questoes" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${escape_html(sobre.porque.questoes.titulo)}</h2> <div id="perguntas" class="svelte-1bib3sa"><!--[-->`);
  for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
    let c = each_array_1[$$index_1];
    $$payload.out.push(`<details class="svelte-1bib3sa"><summary class="svelte-1bib3sa">${escape_html(c.nome)}</summary> <p class="svelte-1bib3sa">${escape_html(c.resposta)}</p></details>`);
  }
  $$payload.out.push(`<!--]--></div></div></section> <section id="sobreVelocidade" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${html(sobre.velocidade.titulo)}</h2> <!--[-->`);
  for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
    let p = each_array_2[$$index_2];
    $$payload.out.push(`<p class="svelte-1bib3sa">${html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreMotor" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${escape_html(sobre.motor.titulo)}</h2> <!--[-->`);
  for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
    let p = each_array_3[$$index_3];
    $$payload.out.push(`<p class="svelte-1bib3sa">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobrelanguages" class="svelte-1bib3sa"><div id="titulo" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${escape_html(sobre.linguagens.titulo)}</h2></div> <!--[-->`);
  for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
    let el = each_array_4[$$index_4];
    $$payload.out.push(`<div${attr("id", el.id)} class="svelte-1bib3sa"><h3 class="svelte-1bib3sa">${escape_html(el.nome)}</h3> <p class="svelte-1bib3sa">${escape_html(el.descricao)}</p></div>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreTime" class="svelte-1bib3sa"><h2 class="svelte-1bib3sa">${html(sobre.time.titulo)}</h2> <p class="svelte-1bib3sa">// maria elisa costa <br/> // fernando marques <br/> // bruno teixeira <br/> // ryan lima <br/>// miguel pires <br/> // rodrigo dias <br/> // rafael ricomini</p></section> <section id="sobreContato" class="svelte-1bib3sa"><h3 class="svelte-1bib3sa">${escape_html(sobre.contato.titulo)}</h3> <h2 class="svelte-1bib3sa">saccopper@gmail.com</h2> <h3 class="svelte-1bib3sa">${escape_html(sobre.contato.instagram)}</h3></section></section>`);
  bind_props($$props, { sobre });
  pop();
}
function Tablet($$payload, $$props) {
  push();
  let sobre = $$props["sobre"];
  const each_array = ensure_array_like(sobre.porque.porque.paragrafos);
  const each_array_1 = ensure_array_like(sobre.porque.questoes.conteudo);
  const each_array_2 = ensure_array_like(sobre.velocidade.paragrafos);
  const each_array_3 = ensure_array_like(sobre.motor.paragrafos);
  const each_array_4 = ensure_array_like(sobre.linguagens.lista);
  $$payload.out.push(`<section id="sobre" class="svelte-15wj2dn"><section id="sobreIntro" class="svelte-15wj2dn"><h1 class="svelte-15wj2dn">${html(sobre.intro.titulo)}</h1> <h2 class="svelte-15wj2dn">${html(sobre.intro.subtitulo)}</h2></section> <section id="sobrePorque" class="svelte-15wj2dn"><div id="porque" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${escape_html(sobre.porque.porque.titulo)}</h2> <!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let p = each_array[$$index];
    $$payload.out.push(`<p class="svelte-15wj2dn">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></div> <div id="questoes" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${escape_html(sobre.porque.questoes.titulo)}</h2> <div id="perguntas" class="svelte-15wj2dn"><!--[-->`);
  for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
    let c = each_array_1[$$index_1];
    $$payload.out.push(`<details class="svelte-15wj2dn"><summary class="svelte-15wj2dn">${escape_html(c.nome)}</summary> <p class="svelte-15wj2dn">${escape_html(c.resposta)}</p></details>`);
  }
  $$payload.out.push(`<!--]--></div></div></section> <section id="sobreVelocidade" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${html(sobre.velocidade.titulo)}</h2> <!--[-->`);
  for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
    let p = each_array_2[$$index_2];
    $$payload.out.push(`<p class="svelte-15wj2dn">${html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreMotor" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${escape_html(sobre.motor.titulo)}</h2> <!--[-->`);
  for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
    let p = each_array_3[$$index_3];
    $$payload.out.push(`<p class="svelte-15wj2dn">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobrelanguages" class="svelte-15wj2dn"><div id="titulo" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${escape_html(sobre.linguagens.titulo)}</h2></div> <!--[-->`);
  for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
    let el = each_array_4[$$index_4];
    $$payload.out.push(`<div${attr("id", el.id)} class="svelte-15wj2dn"><h3 class="svelte-15wj2dn">${escape_html(el.nome)}</h3> <p class="svelte-15wj2dn">${escape_html(el.descricao)}</p></div>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreTime" class="svelte-15wj2dn"><h2 class="svelte-15wj2dn">${html(sobre.time.titulo)}</h2> <p class="svelte-15wj2dn">// maria elisa costa <br/> // fernando marques <br/> // bruno teixeira <br/> // ryan lima <br/>// miguel pires <br/> // rodrigo dias <br/> // rafael ricomini</p></section> <section id="sobreContato" class="svelte-15wj2dn"><h3 class="svelte-15wj2dn">${escape_html(sobre.contato.titulo)}</h3> <h2 class="svelte-15wj2dn">saccopper@gmail.com</h2> <h3 class="svelte-15wj2dn">${escape_html(sobre.contato.instagram)}</h3></section></section>`);
  bind_props($$props, { sobre });
  pop();
}
function Note($$payload, $$props) {
  push();
  let sobre = $$props["sobre"];
  const each_array = ensure_array_like(sobre.porque.porque.paragrafos);
  const each_array_1 = ensure_array_like(sobre.porque.questoes.conteudo);
  const each_array_2 = ensure_array_like(sobre.velocidade.paragrafos);
  const each_array_3 = ensure_array_like(sobre.motor.paragrafos);
  const each_array_4 = ensure_array_like(sobre.linguagens.lista);
  $$payload.out.push(`<section id="sobre"><section id="sobreIntro" class="svelte-pnbef6"><h1 class="svelte-pnbef6">${html(sobre.intro.titulo)}</h1> <h2 class="svelte-pnbef6">${html(sobre.intro.subtitulo)}</h2></section> <section id="sobrePorque" class="svelte-pnbef6"><div id="porque" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${escape_html(sobre.porque.porque.titulo)}</h2> <!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let p = each_array[$$index];
    $$payload.out.push(`<p class="svelte-pnbef6">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></div> <div id="questoes" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${escape_html(sobre.porque.questoes.titulo)}</h2> <div id="perguntas" class="svelte-pnbef6"><!--[-->`);
  for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
    let c = each_array_1[$$index_1];
    $$payload.out.push(`<details class="svelte-pnbef6"><summary class="svelte-pnbef6">${escape_html(c.nome)}</summary> <p class="svelte-pnbef6">${escape_html(c.resposta)}</p></details>`);
  }
  $$payload.out.push(`<!--]--></div></div></section> <section id="sobreVelocidade" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${html(sobre.velocidade.titulo)}</h2> <!--[-->`);
  for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
    let p = each_array_2[$$index_2];
    $$payload.out.push(`<p class="svelte-pnbef6">${html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreMotor" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${escape_html(sobre.motor.titulo)}</h2> <!--[-->`);
  for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
    let p = each_array_3[$$index_3];
    $$payload.out.push(`<p class="svelte-pnbef6">${escape_html(p)}</p>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobrelanguages" class="svelte-pnbef6"><div id="titulo" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${escape_html(sobre.linguagens.titulo)}</h2></div> <!--[-->`);
  for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
    let el = each_array_4[$$index_4];
    $$payload.out.push(`<div${attr("id", el.id)} class="svelte-pnbef6"><h3 class="svelte-pnbef6">${escape_html(el.nome)}</h3> <p class="svelte-pnbef6">${escape_html(el.descricao)}</p></div>`);
  }
  $$payload.out.push(`<!--]--></section> <section id="sobreTime" class="svelte-pnbef6"><h2 class="svelte-pnbef6">${html(sobre.time.titulo)}</h2> <p class="svelte-pnbef6">// maria elisa costa <br/> // fernando marques <br/> // bruno teixeira <br/> // ryan lima <br/>// miguel pires <br/> // rodrigo dias <br/> // rafael ricomini</p></section> <section id="sobreContato" class="svelte-pnbef6"><h3 class="svelte-pnbef6">${escape_html(sobre.contato.titulo)}</h3> <h2 class="svelte-pnbef6">saccopper@gmail.com</h2> <h3 class="svelte-pnbef6">${escape_html(sobre.contato.instagram)}</h3></section></section>`);
  bind_props($$props, { sobre });
  pop();
}
function _page($$payload, $$props) {
  push();
  var $$store_subs;
  function pegaConteudo(índice, caminho) {
    let qttd = Number(t(caminho + ".qttd"));
    let conteudo = [];
    for (let i = 1; i <= qttd; i++) {
      conteudo.push({
        nome: t(caminho + índice + i + ".pergunta"),
        resposta: t(caminho + índice + i + ".resposta")
      });
    }
    return conteudo;
  }
  function getSobre() {
    return {
      intro: {
        titulo: t("sobre.sobreintro.titulo"),
        subtitulo: t("sobre.sobreintro.subtitulo")
      },
      porque: {
        porque: {
          titulo: t("sobre.sobreporque.porque.titulo"),
          paragrafos: [
            t("sobre.sobreporque.porque.paragrafos.pr1"),
            t("sobre.sobreporque.porque.paragrafos.pr2")
          ]
        },
        questoes: {
          titulo: t("sobre.sobreporque.questoes.titulo"),
          conteudo: pegaConteudo(".FAQ", "sobre.sobreporque.questoes.conteudo")
        }
      },
      velocidade: {
        titulo: t("sobre.sobrevelocidade.titulo"),
        paragrafos: [
          t("sobre.sobrevelocidade.paragrafos.pr1"),
          t("sobre.sobrevelocidade.paragrafos.pr2"),
          t("sobre.sobrevelocidade.paragrafos.pr3")
        ]
      },
      motor: {
        titulo: t("sobre.sobremotor.titulo"),
        paragrafos: [
          t("sobre.sobremotor.paragrafos.pr1"),
          t("sobre.sobremotor.paragrafos.pr2"),
          t("sobre.sobremotor.paragrafos.pr3")
        ]
      },
      linguagens: {
        titulo: t("sobre.sobrelanguages.titulo"),
        lista: [
          {
            id: t("sobre.sobrelanguages.linguagens.t1.id"),
            nome: t("sobre.sobrelanguages.linguagens.t1.nome"),
            descricao: t("sobre.sobrelanguages.linguagens.t1.descricao")
          },
          {
            id: t("sobre.sobrelanguages.linguagens.t2.id"),
            nome: t("sobre.sobrelanguages.linguagens.t2.nome"),
            descricao: t("sobre.sobrelanguages.linguagens.t2.descricao")
          },
          {
            id: t("sobre.sobrelanguages.linguagens.t3.id"),
            nome: t("sobre.sobrelanguages.linguagens.t3.nome"),
            descricao: t("sobre.sobrelanguages.linguagens.t3.descricao")
          }
        ]
      },
      time: { titulo: t("sobre.sobretime.titulo") },
      contato: {
        titulo: t("sobre.sobrecontato.titulo"),
        instagram: t("sobre.sobrecontato.instagram")
      }
    };
  }
  let sobre = getSobre();
  store_get($$store_subs ??= {}, "$razao", razao) < 0.5 ? "celular" : store_get($$store_subs ??= {}, "$razao", razao) < 1 ? "tablet" : store_get($$store_subs ??= {}, "$razao", razao) > 1 ? "computador" : "";
  store_get($$store_subs ??= {}, "$lang", lang), sobre = getSobre();
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    Cell($$payload, { sobre });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Tablet($$payload, { sobre });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note($$payload, { sobre });
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
export {
  _page as default
};
