import { M as store_get, A as attr, N as escape_html, Q as unsubscribe_stores, J as bind_props, z as pop, x as push } from "../../../../chunks/index2.js";
import { r as razao } from "../../../../chunks/tela.js";
import { t, l as lang } from "../../../../chunks/language.js";
import { P as Paragrafo } from "../../../../chunks/Conteudo.js";
import { h as html } from "../../../../chunks/html.js";
function _page($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let conteudoslug = {
    titulo: t("docs.doc" + data.id + ".titulo"),
    conteudo: Paragrafo("docs.doc" + data.id)
  };
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    conteudoslug = {
      titulo: t("docs.doc" + data.id + ".titulo"),
      conteudo: Paragrafo("docs.doc" + data.id)
    };
  }
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.63) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<section${attr("id", data.slug)} class="conteudo celular"><h1>${escape_html(conteudoslug.titulo)}</h1> ${html(conteudoslug.conteudo)}</section>`);
  } else {
    $$payload.out.push("<!--[!-->");
    if (store_get($$store_subs ??= {}, "$razao", razao) > 0.63 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<section${attr("id", data.slug)} class="conteudo tablet"><h1>${escape_html(conteudoslug.titulo)}</h1> ${html(conteudoslug.conteudo)}</section>`);
    } else {
      $$payload.out.push("<!--[!-->");
      if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<section${attr("id", data.slug)} class="conteudo computador"><h1>${escape_html(conteudoslug.titulo)}</h1> ${html(conteudoslug.conteudo)}</section>`);
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]-->`);
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}
export {
  _page as default
};
