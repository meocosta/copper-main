import * as universal from '../entries/pages/docs/_slug_/_page.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/docs/_slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/docs/[slug]/+page.ts";
export const imports = ["_app/immutable/nodes/5.Vvno9phd.js","_app/immutable/chunks/Dr3Oo74Z.js","_app/immutable/chunks/Ce9jhLaN.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/Ca2N0swm.js","_app/immutable/chunks/BfGV9M9Z.js","_app/immutable/chunks/BBCc6uHp.js","_app/immutable/chunks/BSH_7Kz2.js"];
export const stylesheets = ["_app/immutable/assets/5.P_tcWmO-.css"];
export const fonts = [];
