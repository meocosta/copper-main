import{i as V,a as re,s as ke}from"../chunks/DeSNcceG.js";import{o as we,s as ft}from"../chunks/CAJekPQE.js";import{bb as ht,g as c,q as mt,aK as vt,a2 as j,bc as Be,L as gt,aY as R,ao as _e,b9 as U,Y as T,X as de,aH as fe,bd as Me,af as J,aG as O,ai as C,ab as w,aj as Q,aa as A,N as q,ak as M,ac as y,ae as b,o as ie,ag as be,ah as Qe,aF as pt,aB as wt,am as _t}from"../chunks/D2NI_LFk.js";import{o as Y,f as Ze,s as et,e as ve}from"../chunks/DGgH5txR.js";import{s as Z,a as bt}from"../chunks/BfGV9M9Z.js";import{p as S,l as L,s as D}from"../chunks/BSH_7Kz2.js";import{h as yt}from"../chunks/Ca2N0swm.js";import{r as tt,v as $t,a as Et}from"../chunks/CqaOjL9a.js";import{i as rt,s as K,c as je}from"../chunks/BBCc6uHp.js";import{e as xe,i as Ae}from"../chunks/RTMQBieC.js";import{c as ze}from"../chunks/Dqu3nJAb.js";import{s as W}from"../chunks/D-rmIOUD.js";import{I as G}from"../chunks/C6-8pd6h.js";import{l as he,t as I}from"../chunks/Ce9jhLaN.js";import{p as St}from"../chunks/BwTyX9cI.js";import{s as kt,p as Mt}from"../chunks/BlPPl959.js";function me(t){let e=0,r=mt(0),n;return()=>{ht()&&(c(r),vt(()=>(e===0&&(n=j(()=>t(()=>Be(r)))),e+=1,()=>{gt(()=>{e-=1,e===0&&(n?.(),n=void 0,Be(r))})})))}}const xt=""+new URL("../assets/favicon.Cz0ONW_9.svg",import.meta.url).href,nt=typeof window<"u"?window:void 0;function At(t){let e=t.activeElement;for(;e?.shadowRoot;){const r=e.shadowRoot.activeElement;if(r===e)break;e=r}return e}class zt{#t;#e;constructor(e,r){this.#t=e,this.#e=me(r)}get current(){return this.#e(),this.#t()}}const Tt=/\(.+\)/,Ct=new Set(["all","print","screen","and","or","not","only"]);class Nt extends zt{constructor(e,r){let n=Tt.test(e)||e.split(/[\s,]+/).some(o=>Ct.has(o.trim()))?e:`(${e})`;const a=window.matchMedia(n);super(()=>a.matches,o=>Y(a,"change",o))}}let Pt=class{#t;#e;constructor(e={}){const{window:r=nt,document:n=r?.document}=e;r!==void 0&&(this.#t=n,this.#e=me(a=>{const o=Y(r,"focusin",a),s=Y(r,"focusout",a);return()=>{o(),s()}}))}get current(){return this.#e?.(),this.#t?At(this.#t):null}};new Pt;function It(t,e){switch(t){case"post":_e(e);break;case"pre":R(e);break}}function ot(t,e,r,n={}){const{lazy:a=!1}=n;let o=!a,s=Array.isArray(t)?[]:void 0;It(e,()=>{const i=Array.isArray(t)?t.map(d=>d()):t();if(!o){o=!0,s=i;return}const l=j(()=>r(i,s));return s=i,l})}function Te(t,e,r){ot(t,"post",e,r)}function Rt(t,e,r){ot(t,"pre",e,r)}Te.pre=Rt;function Lt(t,e){switch(t){case"local":return e.localStorage;case"session":return e.sessionStorage}}class at{#t;#e;#n;#r;#a;#o=U(0);constructor(e,r,n={}){const{storage:a="local",serializer:o={serialize:JSON.stringify,deserialize:JSON.parse},syncTabs:s=!0,window:i=nt}=n;if(this.#t=r,this.#e=e,this.#n=o,i===void 0)return;const l=Lt(a,i);this.#r=l;const d=l.getItem(e);d!==null?this.#t=this.#s(d):this.#i(r),s&&a==="local"&&(this.#a=me(()=>Y(i,"storage",this.#c)))}get current(){this.#a?.(),c(this.#o);const e=this.#s(this.#r?.getItem(this.#e))??this.#t,r=new WeakMap,n=a=>{if(a===null||a?.constructor.name==="Date"||typeof a!="object")return a;let o=r.get(a);return o||(o=new Proxy(a,{get:(s,i)=>(c(this.#o),n(Reflect.get(s,i))),set:(s,i,l)=>(T(this.#o,c(this.#o)+1),Reflect.set(s,i,l),this.#i(e),!0)}),r.set(a,o)),o};return n(e)}set current(e){this.#i(e),T(this.#o,c(this.#o)+1)}#c=e=>{e.key!==this.#e||e.newValue===null||(this.#t=this.#s(e.newValue),T(this.#o,c(this.#o)+1))};#s(e){try{return this.#n.deserialize(e)}catch(r){console.error(`Error when parsing "${e}" from persisted store "${this.#e}"`,r);return}}#i(e){try{e!=null&&this.#r?.setItem(this.#e,this.#n.serialize(e))}catch(r){console.error(`Error when writing value from persisted store "${this.#e}" to ${this.#r}`,r)}}}function qe(t){return t.filter(e=>e.length>0)}const st={getItem:t=>null,setItem:(t,e)=>{}},oe=typeof document<"u";function Ot(t){return typeof t=="function"}function Bt(t){return t!==null&&typeof t=="object"}const ne=Symbol("box"),Ce=Symbol("is-writable");function jt(t){return Bt(t)&&ne in t}function qt(t){return k.isBox(t)&&Ce in t}function k(t){let e=U(de(t));return{[ne]:!0,[Ce]:!0,get current(){return c(e)},set current(r){T(e,r,!0)}}}function Wt(t,e){const r=fe(t);return e?{[ne]:!0,[Ce]:!0,get current(){return c(r)},set current(n){e(n)}}:{[ne]:!0,get current(){return t()}}}function Ht(t){return k.isBox(t)?t:Ot(t)?k.with(t):k(t)}function Ft(t){return Object.entries(t).reduce((e,[r,n])=>k.isBox(n)?(k.isWritableBox(n)?Object.defineProperty(e,r,{get(){return n.current},set(a){n.current=a}}):Object.defineProperty(e,r,{get(){return n.current}}),e):Object.assign(e,{[r]:n}),{})}function Vt(t){return k.isWritableBox(t)?{[ne]:!0,get current(){return t.current}}:t}k.from=Ht;k.with=Wt;k.flatten=Ft;k.readonly=Vt;k.isBox=jt;k.isWritableBox=qt;function Dt(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var X={},ge,We;function Gt(){if(We)return ge;We=1;var t=/\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,e=/\n/g,r=/^\s*/,n=/^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,a=/^:\s*/,o=/^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,s=/^[;\s]*/,i=/^\s+|\s+$/g,l=`
`,d="/",v="*",g="",u="comment",_="declaration";ge=function(h,m){if(typeof h!="string")throw new TypeError("First argument must be a string");if(!h)return[];m=m||{};var x=1,z=1;function $(p){var f=p.match(e);f&&(x+=f.length);var P=p.lastIndexOf(l);z=~P?p.length-P:z+p.length}function N(){var p={line:x,column:z};return function(f){return f.position=new ae(p),Re(),f}}function ae(p){this.start=p,this.end={line:x,column:z},this.source=m.source}ae.prototype.content=h;function Ie(p){var f=new Error(m.source+":"+x+":"+z+": "+p);if(f.reason=p,f.filename=m.source,f.line=x,f.column=z,f.source=h,!m.silent)throw f}function ee(p){var f=p.exec(h);if(f){var P=f[0];return $(P),h=h.slice(P.length),f}}function Re(){ee(r)}function Le(p){var f;for(p=p||[];f=Oe();)f!==!1&&p.push(f);return p}function Oe(){var p=N();if(!(d!=h.charAt(0)||v!=h.charAt(1))){for(var f=2;g!=h.charAt(f)&&(v!=h.charAt(f)||d!=h.charAt(f+1));)++f;if(f+=2,g===h.charAt(f-1))return Ie("End of comment missing");var P=h.slice(2,f-2);return z+=2,$(P),h=h.slice(f),z+=2,p({type:u,comment:P})}}function lt(){var p=N(),f=ee(n);if(f){if(Oe(),!ee(a))return Ie("property missing ':'");var P=ee(o),dt=p({type:_,property:E(f[0].replace(t,g)),value:P?E(P[0].replace(t,g)):g});return ee(s),dt}}function ut(){var p=[];Le(p);for(var f;f=lt();)f!==!1&&(p.push(f),Le(p));return p}return Re(),ut()};function E(h){return h?h.replace(i,g):g}return ge}var He;function Xt(){if(He)return X;He=1;var t=X&&X.__importDefault||function(n){return n&&n.__esModule?n:{default:n}};Object.defineProperty(X,"__esModule",{value:!0}),X.default=r;var e=t(Gt());function r(n,a){var o=null;if(!n||typeof n!="string")return o;var s=(0,e.default)(n),i=typeof a=="function";return s.forEach(function(l){if(l.type==="declaration"){var d=l.property,v=l.value;i?a(d,v,l):v&&(o=o||{},o[d]=v)}}),o}return X}var Kt=Xt();const Fe=Dt(Kt);Fe.default;function Yt(t,e){const r=RegExp(t,"g");return n=>{if(typeof n!="string")throw new TypeError(`expected an argument of type string, but got ${typeof n}`);return n.match(r)?n.replace(r,e):n}}const Ut=Yt(/[A-Z]/,t=>`-${t.toLowerCase()}`);function Jt(t){if(!t||typeof t!="object"||Array.isArray(t))throw new TypeError(`expected an argument of type object, but got ${typeof t}`);return Object.keys(t).map(e=>`${Ut(e)}: ${t[e]};`).join(`
`)}function Qt(t={}){return Jt(t).replace(`
`," ")}const Zt={position:"absolute",width:"1px",height:"1px",padding:"0",margin:"-1px",overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",borderWidth:"0",transform:"translateX(-100%)"};Qt(Zt);const er=typeof window<"u"?window:void 0;function tr(t){let e=t.activeElement;for(;e?.shadowRoot;){const r=e.shadowRoot.activeElement;if(r===e)break;e=r}return e}class rr{#t;#e;constructor(e={}){const{window:r=er,document:n=r?.document}=e;r!==void 0&&(this.#t=n,this.#e=me(a=>{const o=Y(r,"focusin",a),s=Y(r,"focusout",a);return()=>{o(),s()}}))}get current(){return this.#e?.(),this.#t?tr(this.#t):null}}new rr;const H=k("mode-watcher-mode"),F=k("mode-watcher-theme"),nr=["dark","light","system"];function ye(t){return typeof t!="string"?!1:nr.includes(t)}class or{#t="system";#e=oe?localStorage:st;#n=this.#e.getItem(H.current);#r=ye(this.#n)?this.#n:this.#t;#a=U(de(this.#o()));#o(e=this.#r){return new at(H.current,e,{serializer:{serialize:r=>r,deserialize:r=>ye(r)?r:this.#t}})}constructor(){Me(()=>Te.pre(()=>H.current,(e,r)=>{const n=c(this.#a).current;T(this.#a,this.#o(n),!0),r&&localStorage.removeItem(r)}))}get current(){return c(this.#a).current}set current(e){c(this.#a).current=e}}class ar{#t=void 0;#e=!0;#n=U(de(this.#t));#r=typeof window<"u"&&typeof window.matchMedia=="function"?new Nt("prefers-color-scheme: light"):{current:!1};query(){oe&&T(this.#n,this.#r.current?"light":"dark",!0)}tracking(e){this.#e=e}constructor(){Me(()=>{R(()=>{this.#e&&this.query()})}),this.query=this.query.bind(this),this.tracking=this.tracking.bind(this)}get current(){return c(this.#n)}}const ce=new or,$e=new ar;class sr{#t=oe?localStorage:st;#e=this.#t.getItem(F.current);#n=this.#e===null||this.#e===void 0?"":this.#e;#r=U(de(this.#a()));#a(e=this.#n){return new at(F.current,e,{serializer:{serialize:r=>typeof r!="string"?"":r,deserialize:r=>r}})}constructor(){Me(()=>Te.pre(()=>F.current,(e,r)=>{const n=c(this.#r).current;T(this.#r,this.#a(n),!0),r&&localStorage.removeItem(r)}))}get current(){return c(this.#r).current}set current(e){c(this.#r).current=e}}const se=new sr;let Ve,De,Ge=!1,te=null;function ir(){return te||(te=document.createElement("style"),te.appendChild(document.createTextNode(`* {
		-webkit-transition: none !important;
		-moz-transition: none !important;
		-o-transition: none !important;
		-ms-transition: none !important;
		transition: none !important;
	}`)),te)}function it(t,e=!1){if(typeof document>"u")return;if(!Ge){Ge=!0,t();return}if(typeof window<"u"&&window.__vitest_worker__){t();return}clearTimeout(Ve),clearTimeout(De);const n=ir(),a=()=>document.head.appendChild(n),o=()=>{n.parentNode&&document.head.removeChild(n)};function s(){t(),window.requestAnimationFrame(o)}if(typeof window.requestAnimationFrame<"u"){a(),e?s():window.requestAnimationFrame(()=>{s()});return}a(),Ve=window.setTimeout(()=>{t(),De=window.setTimeout(o,16)},16)}const B=k(void 0),le=k(!0),ue=k(!1),Ee=k([]),Se=k([]);function cr(){const t=fe(()=>{if(!oe)return;const e=ce.current==="system"?$e.current:ce.current,r=qe(Ee.current),n=qe(Se.current);function a(){const o=document.documentElement,s=document.querySelector('meta[name="theme-color"]');e==="light"?(r.length&&o.classList.remove(...r),n.length&&o.classList.add(...n),o.style.colorScheme="light",s&&B.current&&s.setAttribute("content",B.current.light)):(n.length&&o.classList.remove(...n),r.length&&o.classList.add(...r),o.style.colorScheme="dark",s&&B.current&&s.setAttribute("content",B.current.dark))}return le.current?it(a,ue.current):a(),e});return{get current(){return c(t)}}}function lr(){const t=fe(()=>{if(se.current,!oe)return;function e(){document.documentElement.setAttribute("data-theme",se.current)}return le.current?it(e,j(()=>ue.current)):e(),se.current});return{get current(){return c(t)}}}const ct=cr(),ur=lr();function dr(){ce.current=ct.current==="dark"?"light":"dark"}function fr(t){ce.current=t}function hr(t){se.current=t}function mr({defaultMode:t="system",themeColors:e,darkClassNames:r=["dark"],lightClassNames:n=[],defaultTheme:a="",modeStorageKey:o="mode-watcher-mode",themeStorageKey:s="mode-watcher-theme"}){const i=document.documentElement,l=localStorage.getItem(o)??t,d=localStorage.getItem(s)??a,v=l==="light"||l==="system"&&window.matchMedia("(prefers-color-scheme: light)").matches;if(v?(r.length&&i.classList.remove(...r.filter(Boolean)),n.length&&i.classList.add(...n.filter(Boolean))):(n.length&&i.classList.remove(...n.filter(Boolean)),r.length&&i.classList.add(...r.filter(Boolean))),i.style.colorScheme=v?"light":"dark",e){const g=document.querySelector('meta[name="theme-color"]');g&&g.setAttribute("content",l==="light"?e.light:e.dark)}d&&(i.setAttribute("data-theme",d),localStorage.setItem(s,d)),localStorage.setItem(o,l)}var vr=A('<meta name="theme-color"/>');function gr(t,e){J(e,!0);var r=O(),n=C(r);{var a=o=>{var s=vr();q(()=>Z(s,"content",e.themeColors.dark)),w(o,s)};V(n,o=>{e.themeColors&&o(a)})}w(t,r),Q()}var pr=A('<meta name="theme-color"/>'),wr=A("<!> <!>",1);function _r(t,e){J(e,!0);let r=S(e,"trueNonce",3,"");Ze(n=>{var a=wr(),o=C(a);{var s=l=>{var d=pr();q(()=>Z(d,"content",e.themeColors.dark)),w(l,d)};V(o,l=>{e.themeColors&&l(s)})}var i=M(o,2);yt(i,()=>`<script${r()?` nonce=${r()}`:""}>(`+mr.toString()+")("+JSON.stringify(e.initConfig)+");<\/script>"),w(n,a)}),Q()}function br(t,e){J(e,!0);let r=S(e,"track",3,!0),n=S(e,"defaultMode",3,"system"),a=S(e,"disableTransitions",3,!0),o=S(e,"darkClassNames",19,()=>["dark"]),s=S(e,"lightClassNames",19,()=>[]),i=S(e,"defaultTheme",3,""),l=S(e,"nonce",3,""),d=S(e,"themeStorageKey",3,"mode-watcher-theme"),v=S(e,"modeStorageKey",3,"mode-watcher-mode"),g=S(e,"disableHeadScriptInjection",3,!1),u=S(e,"synchronousModeChanges",3,!1);H.current=v(),F.current=d(),Ee.current=o(),Se.current=s(),le.current=a(),B.current=e.themeColors,ue.current=u(),R(()=>{ue.current=u()}),R(()=>{le.current=a()}),R(()=>{B.current=e.themeColors}),R(()=>{Ee.current=o()}),R(()=>{Se.current=s()}),R(()=>{H.current=v()}),R(()=>{F.current=d()}),R(()=>{ct.current,H.current,F.current,ur.current}),we(()=>{$e.tracking(r()),$e.query();const $=localStorage.getItem(H.current);fr(ye($)?$:n());const N=localStorage.getItem(F.current);hr(N||i())});const _={defaultMode:n(),themeColors:e.themeColors,darkClassNames:o(),lightClassNames:s(),defaultTheme:i(),modeStorageKey:v(),themeStorageKey:d()},E=fe(()=>typeof window>"u"?l():"");var h=O(),m=C(h);{var x=$=>{gr($,{get themeColors(){return B.current}})},z=$=>{_r($,{get trueNonce(){return c(E)},get initConfig(){return _},get themeColors(){return B.current}})};V(m,$=>{g()?$(x):$(z,!1)})}w(t,h),Q()}function Xe(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"}],["line",{x1:"12",x2:"12.01",y1:"17",y2:"17"}]];G(t,D({name:"badge-question-mark"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function Ke(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M10 2v8l3-3 3 3V2"}],["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"}]];G(t,D({name:"book-marked"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function Ye(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z"}],["circle",{cx:"12",cy:"12",r:"10"}]];G(t,D({name:"circle-play"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function pe(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M12 15V3"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}],["path",{d:"m7 10 5 5 5-5"}]];G(t,D({name:"download"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function Ue(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];G(t,D({name:"house"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function yr(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];G(t,D({name:"moon"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}function $r(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const n=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];G(t,D({name:"sun"},()=>r,{get iconNode(){return n},children:(a,o)=>{var s=O(),i=C(s);W(i,e,"default",{}),w(a,s)},$$slots:{default:!0}}))}var Er=A("<button><!></button>");function Sr(t,e){const r=L(e,["children","$$slots","$$events","$$legacy"]),n=L(r,["variant","size"]);let a=S(e,"variant",8,"default"),o=S(e,"size",8,"default");var s=Er();bt(s,()=>({class:`${a()??""} ${o()??""}`,...n}),void 0,void 0,"svelte-u6rehq");var i=y(s);W(i,e,"default",{}),b(s),w(t,s)}var kr=A("<!> <!>",1);function Ne(t){Sr(t,{get onclick(){return dr},variant:"outline",size:"icon",children:(e,r)=>{var n=kr(),a=C(n);$r(a,{id:"sun",class:"h-[1.2rem] w-[1.2rem] rotate-0 scale-100 !transition-all dark:-rotate-90 dark:scale-0"});var o=M(a,2);yr(o,{id:"moon",class:"absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 !transition-all dark:rotate-0 dark:scale-100"}),w(e,n)},$$slots:{default:!0}})}function Je(t){he.set(t)}function Mr(t,e){tt.set(e/t),$t.set(t),Et.set(e)}var xr=A('<section id="changeLanguage" class="svelte-a15lk3"><button id="languageselector" type="button" aria-label="Change language" class="svelte-a15lk3"><span id="txt"> </span></button> <div id="options"><button>BR</button> <button>US</button></div></section>');function Pe(t,e){J(e,!1);const[r,n]=ke(),a=()=>re(he,"$lang",r);let o=ie(!1),s=ie(i());function i(){switch(a()){case"pt_br":return"BR";case"en_us":return"US";default:return""}}be(()=>a(),()=>{a(),T(s,i())}),Qe(),rt();var l=xr(),d=y(l),v=y(d),g=y(v,!0);b(v),b(d);var u=M(d,2);let _;var E=y(u);let h;var m=M(E,2);let x;b(u),b(l),q((z,$,N)=>{et(g,c(s)),_=K(u,1,"svelte-a15lk3",null,_,z),h=K(E,1,je(a()=="pt_br"?"ativo":""),"svelte-a15lk3",h,$),x=K(m,1,je(a()=="en_us"?"ativo":""),"svelte-a15lk3",x,N)},[()=>({open:c(o)}),()=>({open:c(o)}),()=>({open:c(o)})]),ve("click",d,()=>{T(o,!c(o))}),ve("click",E,()=>{Je("pt_br"),T(o,!1)}),ve("click",m,()=>{Je("en_us"),T(o,!1)}),w(t,l),Q(),n()}var Ar=A('<a class="svelte-1x9yc5n"><button><!></button></a>'),zr=A('<section id="HeaderSection" class="svelte-1x9yc5n"><header class="svelte-1x9yc5n"><h1>.crs</h1> <div class="pointer svelte-1x9yc5n"><!> <!></div></header> <nav class="svelte-1x9yc5n"></nav></section>');function Tr(t,e){let r=S(e,"aba",24,()=>[]),n=S(e,"abaAtual",8,"/");var a=zr(),o=y(a),s=M(y(o),2),i=y(s);Ne(i);var l=M(i,2);Pe(l,{}),b(s),b(o);var d=M(o,2);xe(d,5,r,Ae,(v,g)=>{var u=Ar(),_=y(u);let E;var h=y(_);ze(h,()=>c(g).icon,(m,x)=>{x(m,{class:"icone"})}),b(_),b(u),q(m=>{Z(u,"href",(c(g),j(()=>c(g).href))),E=K(_,1,"svelte-1x9yc5n",null,E,m)},[()=>({ativo:n()===(c(g).href==="/"?"home":c(g).href.slice(1))})]),w(v,u)}),b(d),b(a),w(t,a)}var Cr=A("<p> </p>"),Nr=A('<a class="svelte-136l02w"><button><!> <!></button></a>'),Pr=A('<section id="HeaderSection" class="svelte-136l02w"><div id="header" class="svelte-136l02w"><header class="svelte-136l02w"><h1 class="svelte-136l02w">Copper</h1></header> <nav class="svelte-136l02w"><!> <!> <div class="pointer"><!></div></nav></div></section>');function Ir(t,e){let r=S(e,"aba",24,()=>[]),n=S(e,"abaAtual",8,"/");var a=Pr(),o=y(a),s=M(y(o),2),i=y(s);xe(i,1,r,Ae,(g,u)=>{var _=Nr(),E=y(_);let h;var m=y(E);ze(m,()=>c(u).icon,($,N)=>{N($,{class:"icone"})});var x=M(m,2);{var z=$=>{var N=Cr(),ae=y(N,!0);b(N),q(()=>et(ae,(c(u),j(()=>c(u).titulo)))),w($,N)};V(x,$=>{pt(n()),c(u),j(()=>n()===(c(u).href==="/"?"home":c(u).href.slice(1)))&&$(z)})}b(E),b(_),q($=>{Z(_,"href",(c(u),j(()=>c(u).href))),h=K(E,1,"svelte-136l02w",null,h,$)},[()=>({ativo:n()===(c(u).href==="/"?"home":c(u).href.slice(1))})]),w(g,_)});var l=M(i,2);Pe(l,{});var d=M(l,2),v=y(d);Ne(v),b(d),b(s),b(o),b(a),w(t,a)}var Rr=A('<a class="svelte-188vowt"><button><!></button></a>'),Lr=A('<section id="HeaderSection" class="svelte-188vowt"><div id="header" class="svelte-188vowt"><header class="svelte-188vowt"><h1>.crs</h1></header> <nav class="svelte-188vowt"></nav></div> <div id="lateral" class="svelte-188vowt"><!> <div class="pointer"><!></div></div></section>');function Or(t,e){let r=S(e,"aba",24,()=>[]),n=S(e,"abaAtual",8,"/");var a=Lr(),o=y(a),s=M(y(o),2);xe(s,5,r,Ae,(g,u)=>{var _=Rr(),E=y(_);let h;var m=y(E);ze(m,()=>c(u).icon,(x,z)=>{z(x,{class:"icone"})}),b(E),b(_),q(x=>{Z(_,"href",(c(u),j(()=>c(u).href))),h=K(E,1,"svelte-188vowt",null,h,x)},[()=>({ativo:n()===(c(u).href==="/"?"home":c(u).href.slice(1))})]),w(g,_)}),b(s),b(o);var i=M(o,2),l=y(i);Pe(l,{});var d=M(l,2),v=y(d);Ne(v),b(d),b(i),b(a),w(t,a)}var Br=A("<!> <!> <!>",1);function jr(t,e){J(e,!1);const[r,n]=ke(),a=()=>re(St,"$page",r),o=()=>re(he,"$lang",r),s=()=>re(tt,"$razao",r),i=ie();let l=ie([{icon:Ue,titulo:I("layout.nav.home"),href:"/"},{icon:Xe,titulo:I("layout.nav.sobre"),href:"/sobre"},{icon:Ke,titulo:I("layout.nav.documentos"),href:"/docs"},{icon:Ye,titulo:I("layout.nav.playground"),href:"/play"},{icon:pe,titulo:I("layout.nav.down"),href:"/download"}]);be(()=>a(),()=>{T(i,a().url.pathname.split("/").pop()||"home")}),be(()=>(o(),pe),()=>{o(),T(l,[{icon:Ue,titulo:I("layout.nav.home"),href:"/"},{icon:Xe,titulo:I("layout.nav.sobre"),href:"/sobre"},{icon:Ke,titulo:I("layout.nav.documentos"),href:"/docs"},{icon:Ye,titulo:I("layout.nav.playground"),href:"/play"},{icon:pe,titulo:I("layout.nav.down"),href:"/download"}])}),Qe(),rt();var d=Br(),v=C(d);{var g=m=>{Tr(m,{get aba(){return c(l)},get abaAtual(){return c(i)}})};V(v,m=>{s()<=.6&&m(g)})}var u=M(v,2);{var _=m=>{Or(m,{get aba(){return c(l)},get abaAtual(){return c(i)}})};V(u,m=>{s()>.6&&s()<1&&m(_)})}var E=M(u,2);{var h=m=>{Ir(m,{get aba(){return c(l)},get abaAtual(){return c(i)}})};V(E,m=>{s()>1&&m(h)})}w(t,d),Q(),n()}var qr=A('<section id="footer"></section>');function Wr(t){var e=qr();w(t,e)}const Hr=wt(0),Fr={get url(){return Mt.url}};kt.updated.check;const Vr=Fr;var Dr=A('<link rel="icon" class="svelte-10njqxr"/>'),Gr=A("<!> <!> <!> <!>",1);function dn(t,e){J(e,!0);const[r,n]=ke(),a=()=>re(he,"$lang",r);_e(()=>{a(),I("layout.faixa")});let o=U(null);_e(()=>{const u=Vr.url.pathname;if(c(o)===null){T(o,u,!0);return}u!==c(o)&&(T(o,u,!0),window.location.reload())});function s(){Hr.set(document.body.scrollTop)}we(()=>{const u=()=>Mr(window.innerHeight,window.innerWidth);return u(),window.addEventListener("resize",u),()=>window.removeEventListener("resize",u)}),we(()=>(window.addEventListener("scroll",s),()=>window.removeEventListener("scroll",s)));var i=Gr();Ze(u=>{var _=Dr();q(()=>Z(_,"href",xt)),w(u,_)});var l=C(i);jr(l,{});var d=M(l,2);br(d,{});var v=M(d,2);ft(v,()=>e.children??_t);var g=M(v,2);Wr(g),w(t,i),Q(),n()}export{dn as component};
