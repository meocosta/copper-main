

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/docs/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.sOFrErA6.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/RTMQBieC.js","_app/immutable/chunks/D-rmIOUD.js","_app/immutable/chunks/BfGV9M9Z.js","_app/immutable/chunks/BBCc6uHp.js","_app/immutable/chunks/BSH_7Kz2.js","_app/immutable/chunks/Ce9jhLaN.js","_app/immutable/chunks/Dr3Oo74Z.js","_app/immutable/chunks/COuRMj7W.js","_app/immutable/chunks/BqcczULu.js","_app/immutable/chunks/CAJekPQE.js","_app/immutable/chunks/D0iwhpLH.js"];
export const stylesheets = ["_app/immutable/assets/2.DDCarJsk.css"];
export const fonts = [];
