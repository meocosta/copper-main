import{i as F,s as se,a as E}from"../chunks/DeSNcceG.js";import{r as oe}from"../chunks/CqaOjL9a.js";import{aG as U,ai as L,ab as I,af as B,aa as T,ac as t,a2 as g,aF as y,ae as e,ak as n,N as D,aj as G,o as W,ag as Q,ah as R,Y as w,g as i,$ as ae}from"../chunks/D2NI_LFk.js";import{i as V,s as K}from"../chunks/BBCc6uHp.js";import{s as H,e as O}from"../chunks/DGgH5txR.js";import{h as M}from"../chunks/Ca2N0swm.js";import{l as X,s as Z,p as P}from"../chunks/BSH_7Kz2.js";import{s as ee}from"../chunks/D-rmIOUD.js";import{I as te}from"../chunks/C6-8pd6h.js";import{t as C,l as ve}from"../chunks/Ce9jhLaN.js";import{o as me}from"../chunks/CAJekPQE.js";import{e as ne,i as ce}from"../chunks/RTMQBieC.js";import{c as ue}from"../chunks/Dqu3nJAb.js";function pe($,r){const a=X(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"}],["circle",{cx:"12",cy:"12",r:"4"}]];te($,Z({name:"bolt"},()=>a,{get iconNode(){return c},children:(o,s)=>{var l=U(),d=L(l);ee(d,r,"default",{}),I(o,l)},$$slots:{default:!0}}))}function be($,r){const a=X(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M12 8V4H8"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2"}],["path",{d:"M2 14h2"}],["path",{d:"M20 14h2"}],["path",{d:"M15 13v2"}],["path",{d:"M9 13v2"}]];te($,Z({name:"bot"},()=>a,{get iconNode(){return c},children:(o,s)=>{var l=U(),d=L(l);ee(d,r,"default",{}),I(o,l)},$$slots:{default:!0}}))}function fe($,r){const a=X(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"m18 16 4-4-4-4"}],["path",{d:"m6 8-4 4 4 4"}],["path",{d:"m14.5 4-5 16"}]];te($,Z({name:"code-xml"},()=>a,{get iconNode(){return c},children:(o,s)=>{var l=U(),d=L(l);ee(d,r,"default",{}),I(o,l)},$$slots:{default:!0}}))}function ie($,r){const a=X(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"}]];te($,Z({name:"play"},()=>a,{get iconNode(){return c},children:(o,s)=>{var l=U(),d=L(l);ee(d,r,"default",{}),I(o,l)},$$slots:{default:!0}}))}function de($,r){const a=X(r,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.542.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const c=[["path",{d:"M21 7 6.82 21.18a2.83 2.83 0 0 1-3.99-.01a2.83 2.83 0 0 1 0-4L17 3"}],["path",{d:"m16 2 6 6"}],["path",{d:"M12 16H4"}]];te($,Z({name:"test-tube-diagonal"},()=>a,{get iconNode(){return c},children:(o,s)=>{var l=U(),d=L(l);ee(d,r,"default",{}),I(o,l)},$$slots:{default:!0}}))}var ge=T('<section id="IntroHome" class="svelte-v6vjp4"><h2 class="svelte-v6vjp4"><!></h2> <h3 class="svelte-v6vjp4"> </h3> <div id="botoes" class="svelte-v6vjp4"><button id="teste" class="svelte-v6vjp4"><a href="/play" class="svelte-v6vjp4"><!> </a></button> <button id="start" class="svelte-v6vjp4"><a href="/docs/introducao" class="svelte-v6vjp4"><!> </a></button></div></section>');function $e($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"botoes",24,()=>[]);V();var o=ge(),s=t(o),l=t(s);M(l,()=>(y(a()),g(()=>a()[0]))),e(s);var d=n(s,2),_=t(d,!0);e(d);var m=n(d,2),f=t(m),p=t(f),x=t(p);de(x,{});var N=n(x);e(p),e(f);var b=n(f,2),v=t(b),h=t(v);ie(h,{});var z=n(h);e(v),e(b),e(m),e(o),D(()=>{H(_,(y(a()),g(()=>a()[1]))),H(N,` ${y(c()),g(()=>c()[0])??""}`),H(z,` ${y(c()),g(()=>c()[1])??""}`)}),I($,o),G()}var xe=T('<section id="IntroHome" class="svelte-1jn52vb"><h2 class="svelte-1jn52vb"><!></h2> <h3 class="svelte-1jn52vb"> </h3> <div id="botoes" class="svelte-1jn52vb"><button id="teste" class="svelte-1jn52vb"><a href="/play" class="svelte-1jn52vb"><!> </a></button> <button id="start" class="svelte-1jn52vb"><a href="/docs/introducao" class="svelte-1jn52vb"><!> </a></button></div></section>');function ze($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"botoes",24,()=>[]);V();var o=xe(),s=t(o),l=t(s);M(l,()=>(y(a()),g(()=>a()[0]))),e(s);var d=n(s,2),_=t(d,!0);e(d);var m=n(d,2),f=t(m),p=t(f),x=t(p);de(x,{});var N=n(x);e(p),e(f);var b=n(f,2),v=t(b),h=t(v);ie(h,{});var z=n(h);e(v),e(b),e(m),e(o),D(()=>{H(_,(y(a()),g(()=>a()[1]))),H(N,` ${y(c()),g(()=>c()[0])??""}`),H(z,` ${y(c()),g(()=>c()[1])??""}`)}),I($,o),G()}var ye=T('<section id="IntroHome" class="svelte-sg00a3"><h2 class="svelte-sg00a3"><!></h2> <h3 class="svelte-sg00a3"> </h3> <div id="botoes" class="svelte-sg00a3"><button id="teste" class="svelte-sg00a3"><a href="/play" class="svelte-sg00a3"><!> <p> </p></a></button> <button id="start" class="svelte-sg00a3"><a href="/docs/introducao" class="svelte-sg00a3"><!> <p> </p></a></button></div></section>');function Ne($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"botoes",24,()=>[]);V();var o=ye(),s=t(o),l=t(s);M(l,()=>(y(a()),g(()=>a()[0]))),e(s);var d=n(s,2),_=t(d,!0);e(d);var m=n(d,2),f=t(m),p=t(f),x=t(p);de(x,{});var N=n(x,2),b=t(N,!0);e(N),e(p),e(f);var v=n(f,2),h=t(v),z=t(h);ie(z,{});var u=n(z,2),j=t(u,!0);e(u),e(h),e(v),e(m),e(o),D(()=>{H(_,(y(a()),g(()=>a()[1]))),H(b,(y(c()),g(()=>c()[0]))),H(j,(y(c()),g(()=>c()[1])))}),I($,o),G()}var je=T("<!> <!> <!>",1);function ke($,r){B(r,!1);const[a,c]=se(),o=()=>E(ve,"$lang",a),s=()=>E(oe,"$razao",a);let l="home.intro",d=W([C(l+".titulo"),C(l+".subtitulo")]),_=W([C(l+".botoes.teste"),C(l+".botoes.start")]);Q(()=>(o(),C),()=>{o(),w(d,[C(l+".titulo"),C(l+".subtitulo")]),w(_,[C(l+".botoes.teste"),C(l+".botoes.start")])}),R(),V();var m=je(),f=L(m);{var p=h=>{Ne(h,{get conteudo(){return i(d)},get botoes(){return i(_)}})};F(f,h=>{s()<.63&&h(p)})}var x=n(f,2);{var N=h=>{$e(h,{get conteudo(){return i(d)},get botoes(){return i(_)}})};F(x,h=>{s()>.63&&s()<1&&h(N)})}var b=n(x,2);{var v=h=>{ze(h,{get conteudo(){return i(d)},get botoes(){return i(_)}})};F(b,h=>{s()>1&&h(v)})}I($,m),G(),c()}var Ce=T('<div><h3 class="svelte-dln6mi"> </h3> <p class="svelte-dln6mi"> </p></div>'),we=T('<section id="ferramentas" class="svelte-dln6mi"><div id="txt" class="svelte-dln6mi"><h2 class="svelte-dln6mi"><!></h2> <p class="svelte-dln6mi"> </p></div> <div id="carrosel" class="svelte-dln6mi"></div></section>');function Me($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"titulo",8,""),o=P(r,"subtitulo",8,""),s=["d1","a","d2"],l=W([]);me(()=>{w(l,a().map((b,v)=>v%3)),setInterval(()=>{w(l,i(l).map(b=>(b+1)%3))},4e3)}),V();var d=we(),_=t(d),m=t(_),f=t(m);M(f,c),e(m);var p=n(m,2),x=t(p,!0);e(p),e(_);var N=n(_,2);ne(N,5,a,ce,(b,v,h)=>{var z=Ce(),u=t(z),j=t(u,!0);e(u);var q=n(u,2),k=t(q,!0);e(q),e(z),D(()=>{K(z,1,`card ${i(l),g(()=>s[i(l)[h]])??""}`,"svelte-dln6mi"),H(j,(i(v),g(()=>i(v).nome))),H(k,(i(v),g(()=>i(v).txt)))}),I(b,z)}),e(N),e(d),D(()=>H(x,o())),I($,d),G()}var Ie=T('<section id="CarroselHome" class="svelte-1snzxln"><h2 class="svelte-1snzxln"><!></h2> <div id="card" class="svelte-1snzxln"><div class="svelte-1snzxln"><!> <h3 class="svelte-1snzxln"> </h3></div> <p class="svelte-1snzxln"> </p></div> <div id="bals" class="svelte-1snzxln"><div></div> <div></div> <div></div></div></section>');function He($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"titulo",8,""),o=W(a()[0]),s=W(1);setInterval(()=>{switch(i(s)){case 1:w(o,a()[0]),ae(s);break;case 2:w(o,a()[1]),ae(s);break;case 3:w(o,a()[2]),w(s,1);break}},7e3),Q(()=>(y(a()),i(s)),()=>{w(o,a()[i(s)-1])}),R(),V();var l=Ie(),d=t(l),_=t(d);M(_,c),e(d);var m=n(d,2),f=t(m),p=t(f);ue(p,()=>i(o).icon,(A,S)=>{S(A,{class:"icone"})});var x=n(p,2),N=t(x,!0);e(x),e(f);var b=n(f,2),v=t(b,!0);e(b),e(m);var h=n(m,2),z=t(h);let u;var j=n(z,2);let q;var k=n(j,2);let Y;e(h),e(l),D((A,S,J)=>{H(N,(i(o),g(()=>i(o).nome))),H(v,(i(o),g(()=>i(o).txt))),u=K(z,1,"ball svelte-1snzxln",null,u,A),q=K(j,1,"ball svelte-1snzxln",null,q,S),Y=K(k,1,"ball svelte-1snzxln",null,Y,J)},[()=>({ativo:i(s)==1}),()=>({ativo:i(s)==2}),()=>({ativo:i(s)==3})]),O("click",z,()=>{w(s,1)}),O("click",j,()=>{w(s,2)}),O("click",k,()=>{w(s,3)}),I($,l),G()}var Pe=T('<section id="CarroselHome" class="svelte-6wm8ts"><h2 class="svelte-6wm8ts"><!></h2> <div id="card" class="svelte-6wm8ts"><!> <h3 class="svelte-6wm8ts"> </h3> <p class="svelte-6wm8ts"> </p></div> <div id="bals" class="svelte-6wm8ts"><div></div> <div></div> <div></div></div></section>');function qe($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"titulo",8,""),o=W(a()[0]),s=W(1);setInterval(()=>{switch(i(s)){case 1:w(o,a()[0]),ae(s);break;case 2:w(o,a()[1]),ae(s);break;case 3:w(o,a()[2]),w(s,1);break}},7e3),Q(()=>(y(a()),i(s)),()=>{w(o,a()[i(s)-1])}),R(),V();var l=Pe(),d=t(l),_=t(d);M(_,c),e(d);var m=n(d,2),f=t(m);ue(f,()=>i(o).icon,(Y,A)=>{A(Y,{class:"icone"})});var p=n(f,2),x=t(p,!0);e(p);var N=n(p,2),b=t(N,!0);e(N),e(m);var v=n(m,2),h=t(v);let z;var u=n(h,2);let j;var q=n(u,2);let k;e(v),e(l),D((Y,A,S)=>{H(x,(i(o),g(()=>i(o).nome))),H(b,(i(o),g(()=>i(o).txt))),z=K(h,1,"ball svelte-6wm8ts",null,z,Y),j=K(u,1,"ball svelte-6wm8ts",null,j,A),k=K(q,1,"ball svelte-6wm8ts",null,k,S)},[()=>({ativo:i(s)==1}),()=>({ativo:i(s)==2}),()=>({ativo:i(s)==3})]),O("click",h,()=>{w(s,1)}),O("click",u,()=>{w(s,2)}),O("click",q,()=>{w(s,3)}),I($,l),G()}var Te=T("<!> <!> <!>",1);function Ye($,r){B(r,!1);const[a,c]=se(),o=()=>E(ve,"$lang",a),s=()=>E(oe,"$razao",a);let l=[pe,fe,be],d=W(f("home.cards")),_=W(C("home.cards.titulo")),m=W(C("home.cards.subtitulo"));function f(u){let j=[],q=Number(C(u+".quantidade"));for(let k=1;k<=q;k++)j.push({icon:l[k-1],nome:C(u+".conteudo"+k+".nome"),txt:C(u+".conteudo"+k+".txt")});return j}Q(()=>(o(),C),()=>{o(),w(d,f("home.cards")),w(_,C("home.cards.titulo")),w(m,C("home.cards.subtitulo"))}),R(),V();var p=Te(),x=L(p);{var N=u=>{qe(u,{get titulo(){return i(_)},get conteudo(){return i(d)}})};F(x,u=>{s()<.63&&u(N)})}var b=n(x,2);{var v=u=>{He(u,{get titulo(){return i(_)},get conteudo(){return i(d)}})};F(b,u=>{s()>.63&&s()<1&&u(v)})}var h=n(b,2);{var z=u=>{Me(u,{get titulo(){return i(_)},get conteudo(){return i(d)},get subtitulo(){return i(m)}})};F(h,u=>{s()>1&&u(z)})}I($,p),G(),c()}var Ae=T(`<section id="grid" class="svelte-z9unzm"><div class="parent svelte-z9unzm"><div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm"><!></p></div> <div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm"><!></h3></div> <div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm"><!></p></div></div> <div class="parent2 svelte-z9unzm"><div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm"><!></h3></div> <div id="code" class="svelte-z9unzm"><pre class="svelte-z9unzm">
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div class="conteudo svelte-z9unzm"><p class="svelte-z9unzm"><!></p></div> <div class="txt svelte-z9unzm"><h3 class="svelte-z9unzm"><!></h3></div></div></section>`);function We($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]);V();var c=Ae(),o=t(c),s=t(o),l=t(s),d=t(l);M(d,()=>(y(a()),g(()=>a()[0].txt))),e(l),e(s);var _=n(s,2),m=t(_),f=t(m);M(f,()=>(y(a()),g(()=>a()[1].nome))),e(m),e(_);var p=n(_,2),x=t(p),N=t(x);M(N,()=>(y(a()),g(()=>a()[1].txt))),e(x),e(p),e(o);var b=n(o,2),v=t(b),h=t(v),z=t(h);M(z,()=>(y(a()),g(()=>a()[0].nome))),e(h),e(v);var u=n(v,4),j=t(u),q=t(j);M(q,()=>(y(a()),g(()=>a()[2].txt))),e(j),e(u);var k=n(u,2),Y=t(k),A=t(Y);M(A,()=>(y(a()),g(()=>a()[2].nome))),e(Y),e(k),e(b),e(c),I($,c),G()}var Be=T(`<section id="grid" class="svelte-1yobebi"><div class="parent svelte-1yobebi"><div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi"><!></p></div> <div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi"><!></h3></div> <div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi"><!></p></div></div> <div class="parent2 svelte-1yobebi"><div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi"><!></h3></div> <div id="code" class="svelte-1yobebi"><pre class="svelte-1yobebi">
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div class="conteudo svelte-1yobebi"><p class="svelte-1yobebi"><!></p></div> <div class="txt svelte-1yobebi"><h3 class="svelte-1yobebi"><!></h3></div></div></section>`);function Ge($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]);V();var c=Be(),o=t(c),s=t(o),l=t(s),d=t(l);M(d,()=>(y(a()),g(()=>a()[0].txt))),e(l),e(s);var _=n(s,2),m=t(_),f=t(m);M(f,()=>(y(a()),g(()=>a()[1].nome))),e(m),e(_);var p=n(_,2),x=t(p),N=t(x);M(N,()=>(y(a()),g(()=>a()[1].txt))),e(x),e(p),e(o);var b=n(o,2),v=t(b),h=t(v),z=t(h);M(z,()=>(y(a()),g(()=>a()[0].nome))),e(h),e(v);var u=n(v,4),j=t(u),q=t(j);M(q,()=>(y(a()),g(()=>a()[2].txt))),e(j),e(u);var k=n(u,2),Y=t(k),A=t(Y);M(A,()=>(y(a()),g(()=>a()[2].nome))),e(Y),e(k),e(b),e(c),I($,c),G()}var Ve=T(`<section id="grid" class="svelte-1efg8av"><div class="parent svelte-1efg8av"><div id="div1" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av"><!></p></div> <div id="div2" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av"><!></h3></div> <div id="code" class="svelte-1efg8av"><pre>
				<code>
import * from std.io
name = input!("What's your name?")
println!("Your name is $name")
				</code>
			</pre></div> <div id="div4" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av"><!></h3></div> <div id="div5" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av"><!></p></div> <div id="div6" class="txt svelte-1efg8av"><h3 class="svelte-1efg8av"><!></h3></div> <div id="div7" class="conteudo svelte-1efg8av"><p class="svelte-1efg8av"><!></p></div></div></section>`);function Fe($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]);V();var c=Ve(),o=t(c),s=t(o),l=t(s),d=t(l);M(d,()=>(y(a()),g(()=>a()[0].txt))),e(l),e(s);var _=n(s,2),m=t(_),f=t(m);M(f,()=>(y(a()),g(()=>a()[0].nome))),e(m),e(_);var p=n(_,4),x=t(p),N=t(x);M(N,()=>(y(a()),g(()=>a()[2].nome))),e(x),e(p);var b=n(p,2),v=t(b),h=t(v);M(h,()=>(y(a()),g(()=>a()[2].txt))),e(v),e(b);var z=n(b,2),u=t(z),j=t(u);M(j,()=>(y(a()),g(()=>a()[1].nome))),e(u),e(z);var q=n(z,2),k=t(q),Y=t(k);M(Y,()=>(y(a()),g(()=>a()[1].txt))),e(k),e(q),e(o),e(c),I($,c),G()}var Le=T("<!> <!> <!>",1);function Se($,r){B(r,!1);const[a,c]=se(),o=()=>E(ve,"$lang",a),s=()=>E(oe,"$razao",a);let l=W(d("home.carrosel"));function d(v){let h=[],z=Number(C(v+".quantidade"));for(let u=1;u<=z;u++)h.push({nome:C(v+".conteudo"+u+".nome"),txt:C(v+".conteudo"+u+".txt")});return h}Q(()=>o(),()=>{o(),w(l,d("home.carrosel"))}),R(),V();var _=Le(),m=L(_);{var f=v=>{Fe(v,{get conteudo(){return i(l)}})};F(m,v=>{s()<.63&&v(f)})}var p=n(m,2);{var x=v=>{Ge(v,{get conteudo(){return i(l)}})};F(p,v=>{s()>.63&&s()<1&&v(x)})}var N=n(p,2);{var b=v=>{We(v,{get conteudo(){return i(l)}})};F(N,v=>{s()>1&&v(b)})}I($,_),G(),c()}var De=T('<p class="listra svelte-1ubha5p">|</p>'),Ee=T('<div class="conteudo svelte-1ubha5p"><div class="key svelte-1ubha5p"><p> </p></div> <div class="txt svelte-1ubha5p"><h3 class="svelte-1ubha5p"> </h3> <p class="svelte-1ubha5p"> </p></div></div> <!>',1),Je=T('<section class="passo svelte-1ubha5p"><div class="card-slogan svelte-1ubha5p"><h2 class="svelte-1ubha5p"><!></h2></div> <div class="passos svelte-1ubha5p"><h2 class="svelte-1ubha5p"> </h2> <div></div></div></section>');function Ke($,r){B(r,!1);let a=P(r,"conteudo",24,()=>[]),c=P(r,"slogan",8),o=P(r,"titulo",8);V();var s=Je(),l=t(s),d=t(l),_=t(d);M(_,c),e(d),e(l);var m=n(l,2),f=t(m),p=t(f,!0);e(f);var x=n(f,2);ne(x,7,a,N=>N.nome,(N,b,v)=>{var h=Ee(),z=L(h),u=t(z),j=t(u),q=t(j,!0);e(j),e(u);var k=n(u,2),Y=t(k),A=t(Y,!0);e(Y);var S=n(Y,2),J=t(S,!0);e(S),e(k),e(z);var le=n(z,2);{var he=re=>{var _e=De();I(re,_e)};F(le,re=>{y(i(v)),y(a()),g(()=>i(v)+1!=a().length)&&re(he)})}D(()=>{H(q,i(v)+1),H(A,(i(b),g(()=>i(b).nome))),H(J,(i(b),g(()=>i(b).txt)))}),I(N,h)}),e(x),e(m),e(s),D(()=>H(p,o())),I($,s),G()}var Oe=T('<hr class="svelte-oa6t8v"/>'),Qe=T('<div class="conteudo svelte-oa6t8v"><div id="key" class="svelte-oa6t8v"><p class="svelte-oa6t8v"></p></div> <div id="txt" class="svelte-oa6t8v"><h3 class="svelte-oa6t8v"> </h3> <p class="svelte-oa6t8v"> </p></div></div> <!>',1),Re=T('<section id="passo" class="svelte-oa6t8v"><div id="cardSlogan" class="svelte-oa6t8v"><h2 class="svelte-oa6t8v"><!></h2></div> <div id="passos" class="svelte-oa6t8v"><div id="divs" class="svelte-oa6t8v"></div></div></section>');function Ue($,r){let a=P(r,"conteudo",24,()=>[]),c=P(r,"slogan",8);P(r,"titulo",8);var o=Re(),s=t(o),l=t(s),d=t(l);M(d,c),e(l),e(s);var _=n(s,2),m=t(_);ne(m,5,a,ce,(f,p,x,N)=>{var b=Qe(),v=L(b),h=t(v),z=t(h);z.textContent=x+1,e(h);var u=n(h,2),j=t(u),q=t(j,!0);e(j);var k=n(j,2),Y=t(k,!0);e(k),e(u),e(v);var A=n(v,2);{var S=J=>{var le=Oe();I(J,le)};F(A,J=>{x+1!=3&&J(S)})}D(()=>{H(q,(i(p),g(()=>i(p).nome))),H(Y,(i(p),g(()=>i(p).txt)))}),I(f,b)}),e(m),e(_),e(o),I($,o)}var Xe=T("<!> <!>",1);function Ze($,r){B(r,!1);const[a,c]=se(),o=()=>E(ve,"$lang",a),s=()=>E(oe,"$razao",a);let l=W(m("home.passo")),d=W(C("home.passo.titulo")),_=W(C("home.passo.slogan"));function m(v){let h=[],z=Number(C(v+".quantidade"));for(let u=1;u<=z;u++)h.push({nome:C(v+".passo"+u+".nome"),txt:C(v+".passo"+u+".txt")});return h}Q(()=>(o(),C),()=>{o(),w(l,m("home.passo")),w(d,C("home.passo.titulo")),w(_,C("home.passo.slogan"))}),R(),V();var f=Xe(),p=L(f);{var x=v=>{Ue(v,{get conteudo(){return i(l)},get slogan(){return i(_)},get titulo(){return i(d)}})};F(p,v=>{s()<1&&v(x)})}var N=n(p,2);{var b=v=>{Ke(v,{get conteudo(){return i(l)},get slogan(){return i(_)},get titulo(){return i(d)}})};F(N,v=>{s()>1&&v(b)})}I($,f),G(),c()}var et=T("<!> <!> <!> <!>",1);function _t($){var r=et(),a=L(r);ke(a,{});var c=n(a,2);Ye(c,{});var o=n(c,2);Ze(o,{});var s=n(o,2);Se(s,{}),I($,r)}export{_t as component};
