import { t } from "./language.js";
function Conteudo(path) {
  let qttd = Number(t(path + ".qttd"));
  let array = [];
  for (let i = 1; i <= qttd; i++) {
    array.push(
      {
        id: i,
        title: t(path + ".doc" + i + ".titulo"),
        body: Paragrafo(path + ".doc" + i)
      }
    );
  }
  return array;
}
function Paragrafo(totalpath) {
  let retorno = "";
  let qttd = Number(t(totalpath + ".qttd"));
  for (let i = 1; i <= qttd; i++) {
    retorno += " " + t(totalpath + ".prgf" + i);
  }
  return retorno;
}
export {
  Conteudo as C,
  Paragrafo as P
};
