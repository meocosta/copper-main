

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/play/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.Bxg__OvI.js","_app/immutable/chunks/DeSNcceG.js","_app/immutable/chunks/D2NI_LFk.js","_app/immutable/chunks/CqaOjL9a.js","_app/immutable/chunks/DGgH5txR.js","_app/immutable/chunks/BBCc6uHp.js"];
export const stylesheets = ["_app/immutable/assets/7.B_sF67fn.css"];
export const fonts = [];
