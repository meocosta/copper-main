import * as universal from "../../../../src/routes/docs/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/docs/[slug]/+page.svelte";