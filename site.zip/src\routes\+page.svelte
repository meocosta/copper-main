<script lang="ts">
    import Intro from "./home/intro/Intro.svelte";
    import Carrosel from "./home/carrosel/Carrosel.svelte";
    import Grid from "./home/grid/Grid.svelte";
    import Passo from "./home/passoApasso/Passo.svelte";
</script>

<Intro></Intro>
<Carrosel></Carrosel>
<Passo/>
<Grid/>