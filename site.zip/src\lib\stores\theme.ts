import { writable } from 'svelte/store';

//true = light e false = dark
export const tema = writable(true);