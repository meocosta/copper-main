import { M as store_get, N as escape_html, A as attr, Q as unsubscribe_stores, z as pop, x as push } from "../../../chunks/index2.js";
import { r as razao } from "../../../chunks/tela.js";
import { t, l as lang } from "../../../chunks/language.js";
const apple = "/_app/immutable/assets/apple.DpZgs33J.png";
const linux = "/_app/immutable/assets/linux.DggIJM1K.png";
const wins = "/_app/immutable/assets/windows.stb0DRu-.png";
function Cell($$payload, $$props) {
  push();
  var $$store_subs;
  let trad = t("down.titulo");
  let error = t("down.erro");
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    trad = t("down.titulo");
    error = t("down.erro");
  }
  $$payload.out.push(`<section id="downSection" class="svelte-3hzhxa"><h1 class="svelte-3hzhxa">${escape_html(trad)}</h1> <div id="options" class="svelte-3hzhxa"><div class="op svelte-3hzhxa"><div class="svelte-3hzhxa"><img${attr("src", apple)} alt="Brian é chato" class="svelte-3hzhxa"/> <h2>Mac</h2></div> <button class="svelte-3hzhxa">.sh -macos</button></div> <div class="op svelte-3hzhxa"><div class="svelte-3hzhxa"><img${attr("src", wins)} alt="Brian é chato" class="svelte-3hzhxa"/> <h2>Windows</h2></div> <button class="svelte-3hzhxa">.bat</button></div> <div class="op svelte-3hzhxa"><div class="svelte-3hzhxa"><img${attr("src", linux)} alt="Brian é chato" class="svelte-3hzhxa"/> <h2>Linux</h2></div> <button class="svelte-3hzhxa">.sh</button></div></div> <h3 class="svelte-3hzhxa">${escape_html(error)}</h3> <a href="https://github.com/liy77/copper-lang" class="svelte-3hzhxa">GitHub Repo</a></section>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Note($$payload, $$props) {
  push();
  var $$store_subs;
  let trad = t("down.titulo");
  let error = t("down.erro");
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    trad = t("down.titulo");
    error = t("down.erro");
  }
  $$payload.out.push(`<section id="downSection" class="svelte-qfiz03"><h1 class="svelte-qfiz03">${escape_html(trad)}</h1> <div id="options" class="svelte-qfiz03"><div class="op svelte-qfiz03"><div class="svelte-qfiz03"><img${attr("src", apple)} alt="Brian é chato" class="svelte-qfiz03"/> <h2>Mac</h2></div> <button class="svelte-qfiz03">.sh -macos</button></div> <div class="op svelte-qfiz03"><div class="svelte-qfiz03"><img${attr("src", wins)} alt="Brian é chato" class="svelte-qfiz03"/> <h2>Windows</h2></div> <button class="svelte-qfiz03">.bat</button></div> <div class="op svelte-qfiz03"><div class="svelte-qfiz03"><img${attr("src", linux)} alt="Brian é chato" class="svelte-qfiz03"/> <h2>Linux</h2></div> <button class="svelte-qfiz03">.sh</button></div></div> <h3 class="svelte-qfiz03">${escape_html(error)}</h3> <a href="https://github.com/liy77/copper-lang" class="svelte-qfiz03">GitHub Repo</a></section>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function Tablet($$payload, $$props) {
  push();
  var $$store_subs;
  let trad = t("down.titulo");
  let error = t("down.erro");
  {
    store_get($$store_subs ??= {}, "$lang", lang);
    trad = t("down.titulo");
    error = t("down.erro");
  }
  $$payload.out.push(`<section id="downSection" class="svelte-1j8d0a6"><h1 class="svelte-1j8d0a6">${escape_html(trad)}</h1> <div id="options" class="svelte-1j8d0a6"><div class="op svelte-1j8d0a6"><div class="svelte-1j8d0a6"><img${attr("src", apple)} alt="Brian é chato" class="svelte-1j8d0a6"/> <h2>Mac</h2></div> <button class="svelte-1j8d0a6">.sh -macos</button></div> <div class="op svelte-1j8d0a6"><div class="svelte-1j8d0a6"><img${attr("src", wins)} alt="Brian é chato" class="svelte-1j8d0a6"/> <h2>Windows</h2></div> <button class="svelte-1j8d0a6">.bat</button></div> <div class="op svelte-1j8d0a6"><div class="svelte-1j8d0a6"><img${attr("src", linux)} alt="Brian é chato" class="svelte-1j8d0a6"/> <h2>Linux</h2></div> <button class="svelte-1j8d0a6">.sh</button></div></div> <h3 class="svelte-1j8d0a6">${escape_html(error)}</h3> <a href="https://github.com/liy77/copper-lang" class="svelte-1j8d0a6">GitHub Repo</a></section>`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function _page($$payload) {
  var $$store_subs;
  if (store_get($$store_subs ??= {}, "$razao", razao) < 0.5) {
    $$payload.out.push("<!--[-->");
    Cell($$payload);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 0.5 && store_get($$store_subs ??= {}, "$razao", razao) < 1) {
    $$payload.out.push("<!--[-->");
    Tablet($$payload);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> `);
  if (store_get($$store_subs ??= {}, "$razao", razao) > 1) {
    $$payload.out.push("<!--[-->");
    Note($$payload);
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
}
export {
  _page as default
};
