import { w as writable } from "./index.js";
const razao = writable(0);
export {
  razao as r
};
